'use client'

import { useEffect, useState, useCallback, useMemo, useRef } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Checkbox } from '@/components/ui/checkbox'
import {
  ArrowLeft, FileText, ChevronLeft, ChevronRight, ChevronUp, ChevronDown, Plus, Search,
  Trash2, RefreshCw, AlertTriangle, CheckCircle, XCircle, Menu, X, Clock, Users,
  Copy, Check, Repeat, Layers, Star, Zap, GripVertical, Smartphone, Unlock, Calendar, CalendarOff, Pencil, Clock as ClockIcon, Flame, Replace, ArrowRight, BarChart3, ArrowLeftRight, CalendarSync,
  HelpCircle, MousePointerClick
} from 'lucide-react'
import { toast } from 'sonner'
import {
  calcularResumoSemana,
  calcularNutrientesRefeicao,
  calcularPercapitaPorFase,
  emptyNutrienteDia,
  somarNutrientes,
  DIAS_SEMANA_NUTRI,
  CATEGORIAS_ESCOLA_NUTRI,
  FASES_ESCOLARES,
  type NutrienteDia,
  type ResumoNutricionalSemana,
  type FaseEscolar,
} from '@/lib/nutricao-utils'
import { detectarAlergenosPreparacao, detectarAlergenosPreparacaoComOverride, ALERGENOS_LIST, type AlergenoSigla } from '@/lib/alergenos-utils'

// v9.6.4: helper para parsear JSON string de alergenos (vindo do banco)
function parseAlergenosArrayLocal(jsonStr: unknown): AlergenoSigla[] {
  if (!jsonStr || typeof jsonStr !== 'string') return []
  try {
    const arr = JSON.parse(jsonStr)
    if (!Array.isArray(arr)) return []
    return arr.filter((s): s is AlergenoSigla => ['L', 'O', 'T', 'S'].includes(s))
  } catch {
    return []
  }
}
import { normalizeText } from '@/lib/busca-utils'
import { sortItensByRefeicao } from '@/lib/ordenacao-preparacoes'
import { PREPARACAO_CATEGORIAS, getCategoriaInfo } from '@/lib/preparacao-categorias'
// v9.10.0: detecção do ciclo real de semanas (por conteúdo) para o dialog "Gerar Ciclo"
import { detectarCicloReal } from '@/lib/cardapio-ciclo-utils'
import { PreparacaoFormDialog, type PreparacaoLite } from '@/components/preparacao-form-dialog'
import { parseHorarioToMinutes, ordenarPorHorario, contarHorarios, temMultiplosHorarios } from '@/lib/horario-utils'
// v9.10.17: helpers de UX (cópia 1→N, mover várias, abas de ano) + manual de ajuda
import { mapearCopiasDias, prepararMovimentos } from '@/lib/cardapio-ux-utils'
import { AjudaCardapioDialog } from '@/components/ajuda-cardapio-dialog'

// ── Types ──────────────────────────────────────────────────────

interface TipoRefeicao {
  id: string
  codigo: string
  nome: string
  horario: string
  ordem: number
}

interface Alimento {
  id: string
  nome: string
  grupo: string
  medida_caseira: string
  gramas_por_medida: number
  energia_kcal: number
  carboidratos_g: number
  proteinas_g: number
  lipidios_g: number
  fibra_alimentar_g: number
  sodio_mg: number
  ferro_mg: number
  ferro_heme_mg: number
  vitamina_a_mcg: number
  vitamina_c_mg: number
  calcio_mg: number
  magnesio_mg: number
  zinco_mg: number
  acucar_adicionado_g: number
}

interface PercapitaData {
  id: string
  ingrediente_id: string
  fase_escolar: string
  quantidade_gramas: number
  auto_calculado: boolean
}

interface IngredienteComAlimento {
  id: string
  alimento_id: string  // v8: necessário para o sub-dialog de edição de preparação
  quantidade_gramas: number
  mesma_percapita: boolean
  alimento: Alimento
  percapitas: PercapitaData[]
}

interface Preparacao {
  id: string
  nome: string
  descricao: string | null
  modo_preparo: string | null  // v8: necessário para o sub-dialog de edição
  favorita: boolean
  vezes_usada: number
  categoria?: string  // v8: PREPARACAO | PAO | LANCHE | BEBIDA | SOBREMESA
  ingredientes: IngredienteComAlimento[]
}

interface CardapioItem {
  id: string
  tipo_refeicao_id: string
  preparacao_id: string
  porcoes: number
  ordem?: number  // v8: ordem de exibição (0 = auto-sort)
  tipo_refeicao: TipoRefeicao
  preparacao: Preparacao
}

interface CardapioDia {
  id: string
  dia_semana: string
  itens: CardapioItem[]
}

interface CardapioSemana {
  id: string
  numero: number
  data_inicio: string
  data_fim: string
  diferenciada?: boolean  // v8: true se a semana foi manualmente ajustada vs base
  dias: CardapioDia[]
}

interface CardapioFull {
  id: string
  nome: string
  escola_id: string | null
  cardapio_base_id?: string | null  // v8: se preenchido, é instância replicada
  categoria_escola: string
  fase_escolar: string
  status: string
  ano: number
  semestre: number
  dia_pao_frances?: string | null    // v8: dia fixo de pão (SEG..SEX ou null)
  dia_lanche?: string | null         // v8: dia fixo de lanche (SEG..SEX ou null)
  escola?: { id: string; nome: string } | null
  nutricionista?: { id: string; nome: string } | null
  semanas: CardapioSemana[]
  // v8.7: horários customizados por refeição (override do default)
  horarios_refeicoes?: CardapioHorarioRefeicao[]
}

// v8.7: override de horário por cardápio
interface CardapioHorarioRefeicao {
  id: string
  cardapio_id: string
  tipo_refeicao_id: string
  horario: string         // ex: "09h00 / 15h00"
  multiplicador: number   // ex: 2 se tem 2 horários
}

// v9.9.6: Localizar e Substituir preparação (contrato da API localizar-substituir)
interface SubOcorrencia {
  item_id: string
  semana_num: number
  dia_semana: string
  tipo_refeicao_codigo: string
  tipo_refeicao_nome: string
}

interface SubResultado {
  preparacao_id: string
  preparacao_nome: string
  categoria: string | null
  ocorrencias: SubOcorrencia[]
}

interface MetaNutricional {
  id: string
  tipo_refeicao_id: string
  categoria_escola: string
  energia_kcal_min: number
  energia_kcal_max: number
  carboidratos_pct_min: number
  carboidratos_pct_max: number
  proteinas_pct_min: number
  proteinas_pct_max: number
  lipidios_pct_min: number
  lipidios_pct_max: number
  sodio_mg_max: number
  ferro_mg_min: number
  ferro_heme_dias_semana: number
  vitamina_a_mcg_min: number
  vitamina_a_dias_semana: number
  vitamina_c_mg_min: number
  acucar_pct_max: number
  acucar_proibido_menor3: boolean
}

interface CategoriaRefeicao {
  id: string
  categoria_escola: string
  tipo_refeicao_id: string
  percentual_energia: number
  tipo_refeicao: TipoRefeicao
}

// ── v9.9.9: Analisador de Repetições ─────────────────────────────
// Ferramenta de qualidade do cardápio: identifica preparações repetitivas
// varrendo TODAS as semanas (análise 100% client-side, sem API nova).
//
// Métricas por preparação:
//   mesmoDia        → 2+ vezes no MESMO dia (ex.: arroz no almoço e no lanche)
//   consecutivos    → pares de dias letivos seguidos (seg→ter... qui→sex E sex→seg da semana seguinte)
//   streakMaxSemana → maior sequência de dias seguidos DENTRO de uma mesma semana
//   freqPct         → % dos dias letivos do cardápio em que a preparação aparece
//   diaFixo         → concentração num único dia da semana (≥50% das ocorrências, total ≥5)
//
// Níveis:
//   vermelho = repetição forte  (2× no mesmo dia · 4+ dias seguidos na semana · >60% dos dias)
//   amarelo  = atenção          (dias consecutivos · 3 dias seguidos · >40% dos dias · dia fixo)
//   verde    = sem alerta

type RepNivel = 'vermelho' | 'amarelo' | 'verde'

interface RepPrepAnalise {
  preparacao_id: string
  nome: string
  categoria: string
  total: number            // nº de ocorrências no cardápio
  diasDistintos: number    // dias letivos distintos com a preparação
  freqPct: number          // % dos dias letivos com a preparação
  mesmoDia: number         // nº de dias com 2+ ocorrências
  mesmoDiaExtra: number    // ocorrências excedentes somadas (3 no dia = 2 extras)
  consecutivos: number     // pares de dias letivos consecutivos
  streakMaxSemana: number  // maior sequência de dias seguidos dentro de uma semana
  streakSemanaNum: number | null
  streakDias: string[]     // labels dos dias do streak máximo (ex.: ['Terça','Quarta'])
  diaFixo: { label: string; pct: number; total: number } | null
  semanasDistintas: number
  nivel: RepNivel
  ocorrencias: SubOcorrencia[]  // mesmo contrato do Localizar (v9.9.7) → reusa irParaOcorrencia
}

interface RepPorRefeicao {
  tipo_refeicao_id: string
  nome: string
  totalItens: number
  distintas: number        // preparações distintas na refeição
  diasCobertos: number     // dias letivos com itens nessa refeição
  top: Array<{ nome: string; total: number }>  // 3 mais usadas
}

interface AnaliseRepeticao {
  totalItens: number
  totalDiasLetivos: number
  preps: RepPrepAnalise[]
  porRefeicao: RepPorRefeicao[]
  resumo: {
    distintas: number
    vermelhas: number
    amarelas: number
    verdes: number
    diasMesmoDia: number     // dias letivos onde ALGUMA preparação aparece 2+
    paresConsecutivos: number
  }
}

const REP_INDICE_DIA: Record<string, number> = { segunda: 0, terca: 1, quarta: 2, quinta: 3, sexta: 4 }

function analisarRepeticoesCardapio(cardapio: CardapioFull): AnaliseRepeticao | null {
  if (!cardapio?.semanas) return null

  const diasLetivos = new Set<string>()
  let totalItens = 0
  // acumulador por preparação
  const acc = new Map<string, {
    nome: string
    categoria: string
    ocorrencias: SubOcorrencia[]
    porDia: Map<string, number>            // `${semana}-${dia}` → nº de ocorrências naquele dia
  }>()
  // por refeição (variedade)
  const porRef = new Map<string, { nome: string; totalItens: number; porPrep: Map<string, number>; dias: Set<string> }>()
  // por dia → por preparação (para contar dias com QUALQUER prep 2+)
  const porDiaPreps = new Map<string, Map<string, number>>()

  for (const semana of cardapio.semanas) {
    for (const dia of semana.dias) {
      if (!dia.itens?.length) continue
      const diaKey = `${semana.numero}-${dia.dia_semana}`
      diasLetivos.add(diaKey)
      for (const item of dia.itens) {
        totalItens++
        const prep = item.preparacao
        if (!prep) continue
        let a = acc.get(prep.id)
        if (!a) {
          a = { nome: prep.nome, categoria: prep.categoria || 'PREPARACAO', ocorrencias: [], porDia: new Map() }
          acc.set(prep.id, a)
        }
        a.ocorrencias.push({
          item_id: item.id,
          semana_num: semana.numero,
          dia_semana: dia.dia_semana,
          tipo_refeicao_codigo: item.tipo_refeicao?.codigo || '',
          tipo_refeicao_nome: item.tipo_refeicao?.nome || '',
        })
        a.porDia.set(diaKey, (a.porDia.get(diaKey) || 0) + 1)
        // variedade por refeição
        const trId = item.tipo_refeicao_id
        let r = porRef.get(trId)
        if (!r) {
          r = { nome: item.tipo_refeicao?.nome || trId, totalItens: 0, porPrep: new Map(), dias: new Set() }
          porRef.set(trId, r)
        }
        r.totalItens++
        r.dias.add(diaKey)
        r.porPrep.set(prep.id, (r.porPrep.get(prep.id) || 0) + 1)
        // dia → preparação (resumo global de "2× no mesmo dia")
        let dp = porDiaPreps.get(diaKey)
        if (!dp) { dp = new Map(); porDiaPreps.set(diaKey, dp) }
        dp.set(prep.id, (dp.get(prep.id) || 0) + 1)
      }
    }
  }

  const totalDias = diasLetivos.size || 1
  const diaLabelRep = (v: string) => DIAS_SEMANA_NUTRI.find(d => d.value === v)?.label || v

  const preps: RepPrepAnalise[] = []
  let paresConsecutivos = 0

  for (const [pid, a] of acc) {
    const total = a.ocorrencias.length
    const diasDistintos = a.porDia.size
    const freqPct = Math.round((diasDistintos / totalDias) * 100)

    // 2+ no mesmo dia
    let mesmoDia = 0
    let mesmoDiaExtra = 0
    for (const c of a.porDia.values()) {
      if (c >= 2) { mesmoDia++; mesmoDiaExtra += c - 1 }
    }

    // ocorrências ordenadas por (semana, dia) para análise de sequência
    const ordenadas = [...a.ocorrencias].sort((x, y) => {
      if (x.semana_num !== y.semana_num) return x.semana_num - y.semana_num
      return (REP_INDICE_DIA[x.dia_semana] ?? 0) - (REP_INDICE_DIA[y.dia_semana] ?? 0)
    })

    // pares de dias letivos consecutivos (seg→ter...qui→sex e sex→seg da semana seguinte)
    let consecutivos = 0
    for (let i = 1; i < ordenadas.length; i++) {
      const p = ordenadas[i - 1]
      const c = ordenadas[i]
      const pi = REP_INDICE_DIA[p.dia_semana] ?? -1
      const ci = REP_INDICE_DIA[c.dia_semana] ?? -2
      const mesmaSemanaSeguinte = p.semana_num === c.semana_num && ci === pi + 1
      const viradaSemana = c.semana_num === p.semana_num + 1 && pi === 4 && ci === 0
      if (mesmaSemanaSeguinte || viradaSemana) consecutivos++
    }
    paresConsecutivos += consecutivos

    // maior sequência de dias DISTINTOS seguidos dentro de uma mesma semana
    const porSemana = new Map<number, number[]>()
    for (const o of ordenadas) {
      const arr = porSemana.get(o.semana_num) || []
      arr.push(REP_INDICE_DIA[o.dia_semana] ?? 0)
      porSemana.set(o.semana_num, arr)
    }
    let streakMaxSemana = 0
    let streakSemanaNum: number | null = null
    let streakDias: string[] = []
    for (const [w, arr] of porSemana) {
      const uniq = [...new Set(arr)].sort((x, y) => x - y)
      let run = uniq.length ? 1 : 0
      let bestRun = 0
      let bestFrom = 0
      for (let i = 1; i < uniq.length; i++) {
        if (uniq[i] === uniq[i - 1] + 1) run++
        else {
          if (run > bestRun) { bestRun = run; bestFrom = i - run }
          run = 1
        }
      }
      if (run > bestRun) { bestRun = run; bestFrom = uniq.length - run }
      if (bestRun > streakMaxSemana) {
        streakMaxSemana = bestRun
        streakSemanaNum = w
        streakDias = uniq.slice(bestFrom, bestFrom + bestRun).map(idx => diaLabelRep(DIAS_SEMANA_NUTRI[idx]?.value || ''))
      }
    }

    // concentração em um dia da semana (ex.: "sempre segunda")
    const porDiaSemana = new Map<string, number>()
    for (const o of a.ocorrencias) porDiaSemana.set(o.dia_semana, (porDiaSemana.get(o.dia_semana) || 0) + 1)
    let diaFixo: RepPrepAnalise['diaFixo'] = null
    let melhorDia = ''
    let melhorTotal = 0
    for (const [d, c] of porDiaSemana) {
      if (c > melhorTotal) { melhorTotal = c; melhorDia = d }
    }
    if (total >= 5 && melhorTotal > 0) {
      const pct = Math.round((melhorTotal / total) * 100)
      if (pct >= 50) diaFixo = { label: diaLabelRep(melhorDia), pct, total: melhorTotal }
    }

    const semanasDistintas = new Set(a.ocorrencias.map(o => o.semana_num)).size

    // classificação
    // Critérios de % de dias só valem com amostra mínima (3+ ocorrências em 5+ dias letivos),
    // senão cardápios quase vazios geram falso positivo (1 item = 100% de 1 dia)
    const freqConfiavel = total >= 3 && diasLetivos.size >= 5
    let nivel: RepNivel = 'verde'
    if (mesmoDia > 0 || streakMaxSemana >= 4 || (freqConfiavel && freqPct > 60)) nivel = 'vermelho'
    else if (consecutivos > 0 || streakMaxSemana === 3 || (freqConfiavel && freqPct > 40) || diaFixo) nivel = 'amarelo'

    preps.push({
      preparacao_id: pid,
      nome: a.nome,
      categoria: a.categoria,
      total,
      diasDistintos,
      freqPct,
      mesmoDia,
      mesmoDiaExtra,
      consecutivos,
      streakMaxSemana,
      streakSemanaNum,
      streakDias,
      diaFixo,
      semanasDistintas,
      nivel,
      ocorrencias: a.ocorrencias,
    })
  }

  // ordena: vermelho → amarelo → verde; dentro do nível, piores primeiro
  const prioridade: Record<RepNivel, number> = { vermelho: 3, amarelo: 2, verde: 1 }
  preps.sort((x, y) =>
    (prioridade[y.nivel] - prioridade[x.nivel]) ||
    (y.mesmoDiaExtra - x.mesmoDiaExtra) ||
    (y.streakMaxSemana - x.streakMaxSemana) ||
    (y.consecutivos - x.consecutivos) ||
    (y.total - x.total) ||
    x.nome.localeCompare(y.nome)
  )

  // variedade por refeição (mais movimentadas primeiro)
  const porRefeicao: RepPorRefeicao[] = [...porRef.entries()]
    .map(([trId, r]) => ({
      tipo_refeicao_id: trId,
      nome: r.nome,
      totalItens: r.totalItens,
      distintas: r.porPrep.size,
      diasCobertos: r.dias.size,
      top: [...r.porPrep.entries()]
        .map(([p2, c]) => ({ nome: acc.get(p2)?.nome || p2, total: c }))
        .sort((x, y) => y.total - x.total || x.nome.localeCompare(y.nome))
        .slice(0, 3),
    }))
    .sort((x, y) => y.totalItens - x.totalItens)

  // dias letivos onde alguma preparação aparece 2+
  let diasMesmoDia = 0
  for (const dp of porDiaPreps.values()) {
    for (const c of dp.values()) {
      if (c >= 2) { diasMesmoDia++; break }
    }
  }

  return {
    totalItens,
    totalDiasLetivos: diasLetivos.size,
    preps,
    porRefeicao,
    resumo: {
      distintas: acc.size,
      vermelhas: preps.filter(p => p.nivel === 'vermelho').length,
      amarelas: preps.filter(p => p.nivel === 'amarelo').length,
      verdes: preps.filter(p => p.nivel === 'verde').length,
      diasMesmoDia,
      paresConsecutivos,
    },
  }
}

// ── Helpers ────────────────────────────────────────────────────

function getStatusBadge(status: string) {
  switch (status) {
    case 'APROVADO':
      return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 text-[10px]">Aprovado</Badge>
    case 'RASCUNHO':
      return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-[10px]">Rascunho</Badge>
    default:
      return <Badge variant="outline" className="text-[10px]">{status}</Badge>
  }
}

function getFaseLabel(fase: string) {
  const f = FASES_ESCOLARES.find(fs => fs.value === fase)
  return f ? `${f.label} (${f.faixa})` : fase
}

function getFaseColor(fase: string) {
  const f = FASES_ESCOLARES.find(fs => fs.value === fase)
  return f?.cor || '#1A3A5C'
}

function formatDate(dateStr: string) {
  if (!dateStr) return '—'
  const d = new Date(dateStr + 'T12:00:00')
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })
}

function getAlertaIcon(tipo: string) {
  switch (tipo) {
    case 'CRITICO': return <XCircle className="w-3.5 h-3.5 text-red-500 flex-shrink-0" />
    case 'ATENCAO': return <AlertTriangle className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />
    default: return <CheckCircle className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
  }
}

function getAlertaBg(tipo: string) {
  switch (tipo) {
    case 'CRITICO': return 'bg-red-50 border-red-100'
    case 'ATENCAO': return 'bg-amber-50 border-amber-100'
    default: return 'bg-emerald-50 border-emerald-100'
  }
}

// ── Component ──────────────────────────────────────────────────

export default function CardapioEditorPage() {
  const params = useParams()
  const router = useRouter()
  const cardapioId = params.id as string

  const [cardapio, setCardapio] = useState<CardapioFull | null>(null)
  const [preparacoes, setPreparacoes] = useState<Preparacao[]>([])
  const [tiposRefeicao, setTiposRefeicao] = useState<TipoRefeicao[]>([])
  const [categoriasRefeicao, setCategoriasRefeicao] = useState<CategoriaRefeicao[]>([])
  const [metas, setMetas] = useState<MetaNutricional[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [currentSemana, setCurrentSemana] = useState(1)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  // v8: exclusão do cardápio
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [deleting, setDeleting] = useState(false)

  // Add preparations dialog (multi-select)
  const [addDialogOpen, setAddDialogOpen] = useState(false)
  const [addDiaId, setAddDiaId] = useState<string | null>(null)
  const [addTipoRefeicaoId, setAddTipoRefeicaoId] = useState<string | null>(null)
  const [addPrepSearch, setAddPrepSearch] = useState('')
  const [addSelectedPrepIds, setAddSelectedPrepIds] = useState<Set<string>>(new Set())
  const [adding, setAdding] = useState(false)
  // v8: editar/criar/clonar preparação dentro do dialog de adicionar
  const [editingPrepInDialog, setEditingPrepInDialog] = useState<string | null>(null)  // id da prep sendo editada, null = nova
  const [prepDialogOpenInCardapio, setPrepDialogOpenInCardapio] = useState(false)
  // Filtros do modal: todas | favoritas | recentes
  const [addFilter, setAddFilter] = useState<'all' | 'favoritas' | 'recentes'>('all')
  // Filtro alérgenos: exclui preparações com esses alérgenos
  const [addSemAlergenos, setAddSemAlergenos] = useState<Set<string>>(new Set())
  // v9.9.4: itens já presentes no slot quando o dialog abre (modo editar) — preparacao_id → item_id.
  // Permite reabrir o dialog e VER as preparações já selecionadas; desmarcar + salvar remove.
  const [addExistingItems, setAddExistingItems] = useState<Map<string, string>>(new Map())
  // v9.9.4: filtro por categoria da preparação ('all' | valor de PREPARACAO_CATEGORIAS)
  const [addFilterCategoria, setAddFilterCategoria] = useState<string>('all')

  // Fase escolar selector
  const [faseDialogOpen, setFaseDialogOpen] = useState(false)
  // v8: dialog para configurar data de início do cardápio
  const [dataInicioDialogOpen, setDataInicioDialogOpen] = useState(false)
  const [dataInicio, setDataInicio] = useState('')
  // v8: dialog para editar nome do cardápio
  const [nomeDialogOpen, setNomeDialogOpen] = useState(false)
  const [editandoNome, setEditandoNome] = useState('')
  const [selectedFase, setSelectedFase] = useState<string>('FUND_FINAL')

  // Copy day dialog — multi-day support
  const [copyDialogOpen, setCopyDialogOpen] = useState(false)
  const [copyOrigemSemana, setCopyOrigemSemana] = useState<number>(1)
  const [copyOrigemDias, setCopyOrigemDias] = useState<Set<string>>(new Set())
  const [copyDestinoSemana, setCopyDestinoSemana] = useState<number>(1)
  const [copyDestinoDias, setCopyDestinoDias] = useState<Set<string>>(new Set())
  const [copying, setCopying] = useState(false)

  // ── NOVOS v7: quick-add chips, drag-and-drop, mobile day picker, porções editing ──
  // Top 6 preparações mais usadas (para botões 1-clique)
  const [topPreparacoes, setTopPreparacoes] = useState<Preparacao[]>([])
  // Item sendo arrastado (drag-and-drop)
  const [draggedItem, setDraggedItem] = useState<CardapioItem | null>(null)
  const [dragOverSlot, setDragOverSlot] = useState<string | null>(null)
  // v8: dica visual de Alt+Drag = duplicar (banner fixo durante o arrasto)
  const [dragAltHint, setDragAltHint] = useState(false)
  // ── v9.10.2: Modo Troca — clique em 2 preparações e elas trocam de lugar ──
  // modoTroca     → ferramenta ativa (botão ⇄ no cabeçalho do dia)
  // trocaPrimeiro → 1ª preparação selecionada (aguardando a 2ª)
  // trocando      → requisição em andamento (evita duplo clique)
  const [modoTroca, setModoTroca] = useState(false)
  const [trocaPrimeiro, setTrocaPrimeiro] = useState<CardapioItem | null>(null)
  const [trocando, setTrocando] = useState(false)
  // ── v9.10.3: Modo Trocar Dia — troca o DIA INTEIRO de lugar ──
  // modoTrocaDia     → ferramenta ativa (botão 📅⇄ no cabeçalho do dia)
  // trocaDiaPrimeiro → 1º dia selecionado (value 'segunda'..'sexta')
  // trocandoDia      → requisição em andamento (evita duplo clique)
  const [modoTrocaDia, setModoTrocaDia] = useState(false)
  const [trocaDiaPrimeiro, setTrocaDiaPrimeiro] = useState<string | null>(null)
  const [trocandoDia, setTrocandoDia] = useState(false)
  // ── v9.10.17: Modo Mover Várias — marque N preparações e mova todas p/ outro dia ──
  // modoMover         → ferramenta ativa (botão "Mover várias" na barra da semana)
  // moverSelecionados → ids dos itens marcados (clique marca/desmarca)
  // movendo           → requisições em andamento (evita duplo clique)
  const [modoMover, setModoMover] = useState(false)
  const [moverSelecionados, setMoverSelecionados] = useState<Set<string>>(new Set())
  const [movendo, setMovendo] = useState(false)
  // v9.10.17: dialog "Ajuda" — manual visual do editor
  const [ajudaDialogOpen, setAjudaDialogOpen] = useState(false)
  // v9.10.17: ref do campo de busca de preparações (limpa + refocus após selecionar)
  const addPrepSearchRef = useRef<HTMLInputElement | null>(null)
  // Modo mobile: mostra apenas 1 dia por vez (picker no topo)
  const [mobileDayView, setMobileDayView] = useState<string>('segunda')
  // Porções com edição inline em andamento (item_id)
  const [editingPorcoesId, setEditingPorcoesId] = useState<string | null>(null)
  // Versão mobile (sidebar sempre colapsável)
  const [isMobile, setIsMobile] = useState(false)
  // v8: feriados para mostrar badge no editor
  const [feriados, setFeriados] = useState<Array<{ id: string; data: string; nome: string; tipo: string; escolas_afetadas: string }>>([])
  // v8.7: dialog para editar horário customizado de uma refeição
  const [horarioDialogOpen, setHorarioDialogOpen] = useState(false)
  const [horarioEditando, setHorarioEditando] = useState<{ tipoRefeicaoId: string; nome: string; horarioDefault: string; horarioAtual: string } | null>(null)
  const [horarioInput, setHorarioInput] = useState('')
  const [salvandoHorario, setSalvandoHorario] = useState(false)

  // ── v9.9.6: Localizar e Substituir preparação (restaurado) ──
  const [subDialogOpen, setSubDialogOpen] = useState(false)
  const [subBusca, setSubBusca] = useState('')
  const [subBuscando, setSubBuscando] = useState(false)
  const [subResultados, setSubResultados] = useState<SubResultado[] | null>(null)
  const [subPrepSelecionada, setSubPrepSelecionada] = useState<SubResultado | null>(null)
  const [subItensMarcados, setSubItensMarcados] = useState<Set<string>>(new Set())
  const [subNovaId, setSubNovaId] = useState('')
  const [subNovaBusca, setSubNovaBusca] = useState('')
  const [subNovaAberta, setSubNovaAberta] = useState(false)
  const [subExecutando, setSubExecutando] = useState(false)

  // ── v9.9.7: Localizar preparação (separado do Substituir) ──
  // Fluxo somente-leitura: busca → vê ONDE a preparação está (semana/dia/refeição) →
  // clica na ocorrência e a tela pula para aquela semana destacando o item.
  const [locDialogOpen, setLocDialogOpen] = useState(false)
  const [locBusca, setLocBusca] = useState('')
  const [locBuscando, setLocBuscando] = useState(false)
  const [locResultados, setLocResultados] = useState<SubResultado[] | null>(null)
  const [locPrepAberta, setLocPrepAberta] = useState<string | null>(null) // preparacao_id do card expandido
  // Item destacado temporariamente após "Ir" (ring âmbar, limpo por timeout)
  const [locDestaqueItemId, setLocDestaqueItemId] = useState<string | null>(null)
  // Timers dos efeitos de navegação (limpos ao navegar de novo para não piscar)
  const locScrollTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const locClearTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // ── v9.9.9: Analisador de Repetições ──
  const [repDialogOpen, setRepDialogOpen] = useState(false)
  const [repCardAberto, setRepCardAberto] = useState<string | null>(null)   // preparação expandida no ranking
  const [repCat, setRepCat] = useState('all')                              // filtro por categoria
  const [repSoAlertas, setRepSoAlertas] = useState(true)                   // só vermelho+amarelo (default)

  // ── v9.10.0: Gerar Ciclo (repetir as semanas montadas até a 22ª) ──
  const [cicloDialogOpen, setCicloDialogOpen] = useState(false)
  const [gerandoCiclo, setGerandoCiclo] = useState(false)

  // v9.9.6: busca de ocorrências com debounce (GET localizar-substituir)
  useEffect(() => {
    if (!subDialogOpen) return
    const q = subBusca.trim()
    if (q.length < 2) {
      setSubResultados(null)
      setSubBuscando(false)
      return
    }
    setSubBuscando(true)
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/localizar-substituir?q=${encodeURIComponent(q)}`)
        if (!res.ok) throw new Error()
        const data = await res.json()
        setSubResultados(Array.isArray(data.preparacoes) ? data.preparacoes : [])
      } catch {
        setSubResultados([])
      } finally {
        setSubBuscando(false)
      }
    }, 350)
    return () => clearTimeout(t)
  }, [subBusca, subDialogOpen, cardapioId])

  // v9.9.7: busca do Localizar com o mesmo debounce (GET localizar-substituir)
  useEffect(() => {
    if (!locDialogOpen) return
    const q = locBusca.trim()
    if (q.length < 2) {
      setLocResultados(null)
      setLocBuscando(false)
      return
    }
    setLocBuscando(true)
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/localizar-substituir?q=${encodeURIComponent(q)}`)
        if (!res.ok) throw new Error()
        const data = await res.json()
        const preps: SubResultado[] = Array.isArray(data.preparacoes) ? data.preparacoes : []
        setLocResultados(preps)
        // Conveniência: se a busca casou com UMA preparação só, já expande as ocorrências
        setLocPrepAberta(preps.length === 1 ? preps[0].preparacao_id : null)
      } catch {
        setLocResultados([])
      } finally {
        setLocBuscando(false)
      }
    }, 350)
    return () => clearTimeout(t)
  }, [locBusca, locDialogOpen, cardapioId])

  // v9.9.9: análise calculada só quando o dialog está aberto (varredura das 22 semanas)
  const analiseRep = useMemo(() => {
    if (!repDialogOpen || !cardapio) return null
    return analisarRepeticoesCardapio(cardapio)
  }, [repDialogOpen, cardapio])

  // ── v9.10.0: análise do ciclo p/ dialog "Gerar Ciclo" (100% client-side) ──
  // ciclo = maior semana com conteúdo; gerar = semanas ciclo+1..total;
  // foraDoCicloComConteudo = semanas além do ciclo que serão SUBSTITUÍDAS (aviso)
  const analiseCiclo = useMemo(() => {
    if (!cicloDialogOpen || !cardapio) return null
    const total = cardapio.semanas.length || 22
    const ciclo = detectarCicloReal(cardapio.semanas)
    const comConteudo = cardapio.semanas
      .filter(s => (s.dias || []).some(d => d.itens.length > 0))
      .map(s => s.numero)
      .sort((a, b) => a - b)
    const foraDoCicloComConteudo = comConteudo.filter(n => n > ciclo)
    const gerar: number[] = []
    for (let num = ciclo + 1; num <= total; num++) gerar.push(num)
    const mapeamento = gerar.map(num => ({
      semana: num,
      base: ciclo > 0 ? ((num - 1) % ciclo) + 1 : num,
    }))
    return { total, ciclo, comConteudo, foraDoCicloComConteudo, gerar, mapeamento }
  }, [cicloDialogOpen, cardapio])

  // v9.9.9: ranking filtrado (categoria + somente alertas)
  const repFiltradas = useMemo(() => {
    if (!analiseRep) return []
    let list = analiseRep.preps
    if (repCat !== 'all') list = list.filter(p => p.categoria === repCat)
    if (repSoAlertas) list = list.filter(p => p.nivel !== 'verde')
    return list
  }, [analiseRep, repCat, repSoAlertas])

  // v9.9.9: categorias presentes no cardápio (para o filtro)
  const repCategoriasPresentes = useMemo(() => {
    if (!analiseRep) return []
    const set = new Set(analiseRep.preps.map(p => p.categoria))
    return PREPARACAO_CATEGORIAS.filter(c => set.has(c.value))
  }, [analiseRep])

  const loadData = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [cardRes, prepRes, tipoRes, catRes, metaRes, topRes, ferRes] = await Promise.all([
        fetch(`/api/nutricao/cardapios/${cardapioId}`),
        fetch('/api/nutricao/preparacoes'),
        fetch('/api/nutricao/tipos-refeicao'),
        fetch('/api/nutricao/categorias-refeicao'),
        fetch('/api/nutricao/metas'),
        fetch('/api/nutricao/preparacoes?recentes=true&limite_recentes=6'),
        fetch('/api/feriados'),
      ])
      if (!cardRes.ok) throw new Error('Erro ao carregar cardápio')
      const cardData = await cardRes.json()
      const prepData = prepRes.ok ? await prepRes.json() : []
      const tipoData = tipoRes.ok ? await tipoRes.json() : []
      const catData = catRes.ok ? await catRes.json() : []
      const metaData = metaRes.ok ? await metaRes.json() : []
      const topData = topRes.ok ? await topRes.json() : []
      const ferData = ferRes.ok ? await ferRes.json() : []
      setCardapio(cardData)
      setSelectedFase(cardData.fase_escolar || 'FUND_FINAL')
      setPreparacoes(Array.isArray(prepData) ? prepData : [])
      setTiposRefeicao(Array.isArray(tipoData) ? tipoData : [])
      setFeriados(Array.isArray(ferData) ? ferData : [])
      setCategoriasRefeicao(Array.isArray(catData) ? catData : [])
      setMetas(Array.isArray(metaData) ? metaData : [])
      setTopPreparacoes(Array.isArray(topData) ? topData : [])
    } catch (err) {
      console.error(err)
      setError('Não foi possível carregar o cardápio.')
    } finally {
      setLoading(false)
    }
  }, [cardapioId])

  // Detecta mobile/tablet para mudar layout
  useEffect(() => {
    function checkMobile() {
      setIsMobile(window.innerWidth < 1024)
    }
    checkMobile()
    window.addEventListener('resize', checkMobile)
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  useEffect(() => {
    loadData()
  }, [loadData])

  // ── Atalhos de teclado (F4) ──
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      // Ignora se modal aberto ou foco em input
      const target = e.target as HTMLElement
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) return
      if (addDialogOpen || copyDialogOpen || faseDialogOpen) return

      // Alt+Seta esquerda/direita → navega semanas
      if (e.altKey && e.key === 'ArrowLeft') {
        e.preventDefault()
        setCurrentSemana((s) => Math.max(1, s - 1))
      } else if (e.altKey && e.key === 'ArrowRight') {
        e.preventDefault()
        setCurrentSemana((s) => Math.min(cardapio?.semanas.length || 22, s + 1))
      }
      // Alt+1..5 → ir para semana 1..5 (ciclo base)
      else if (e.altKey && /^[1-5]$/.test(e.key)) {
        e.preventDefault()
        setCurrentSemana(Number(e.key))
      }
      // v9.10.2: ESC cancela o Modo Troca | v9.10.3: e o Modo Trocar Dia
      // | v9.10.17: e o Modo Mover Várias
      else if (e.key === 'Escape' && (modoTroca || modoTrocaDia || modoMover)) {
        setModoTroca(false)
        setTrocaPrimeiro(null)
        setModoTrocaDia(false)
        setTrocaDiaPrimeiro(null)
        sairModoMover()
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [addDialogOpen, copyDialogOpen, faseDialogOpen, cardapio, modoTroca, modoTrocaDia, modoMover])

  // Refeições for the current category (with schedule info)
  // v8.7: ORDENA POR HORÁRIO CRONOLÓGICO (não por tipo_refeicao.ordem).
  // Usa horário customizado do cardápio se existir, senão usa default de TipoRefeicao.
  const refeicoesForCategoria = useMemo(() => {
    if (!cardapio) return []
    const lista = categoriasRefeicao.filter((cr) => cr.categoria_escola === cardapio.categoria_escola)
    // Para cada CategoriaRefeicao, anexar o horário efetivo (override se existir)
    const horariosOverride = cardapio.horarios_refeicoes || []
    return ordenarPorHorario(
      lista.map((cr) => {
        const override = horariosOverride.find(h => h.tipo_refeicao_id === cr.tipo_refeicao_id)
        const horarioEfetivo = override?.horario ?? cr.tipo_refeicao.horario
        return {
          ...cr,
          // Adiciona campo virtual para uso na UI
          horario_efetivo: horarioEfetivo,
          horario_override: override ?? null,
        }
      })
    )
  }, [cardapio, categoriasRefeicao])

  // Current semana data
  const semanaAtual = useMemo(() => {
    if (!cardapio) return null
    return cardapio.semanas.find((s) => s.numero === currentSemana) || null
  }, [cardapio, currentSemana])

  // Get items for a specific day + refeição (com auto-sort)
  function getItensForSlot(diaSemana: string, tipoRefeicaoId: string): CardapioItem[] {
    if (!semanaAtual) return []
    const dia = semanaAtual.dias.find((d) => d.dia_semana === diaSemana)
    if (!dia) return []
    // v8: aplica ordenação automática baseada no tipo de refeição
    const itensDoSlot = dia.itens.filter((i) => i.tipo_refeicao_id === tipoRefeicaoId)
    return sortItensByRefeicao(itensDoSlot, tiposRefeicao)
  }

  // v8: Reordenar item dentro do slot (up/down) — OTIMISTICO (sem refresh)
  async function handleReordenarItem(itemId: string, direcao: 'up' | 'down') {
    if (!cardapio || !semanaAtual) return

    // Busca todos os itens do mesmo slot para encontrar qual trocar
    for (const dia of semanaAtual.dias) {
      const itemAtual = dia.itens.find(i => i.id === itemId)
      if (!itemAtual) continue

      // Encontra todos os itens do mesmo slot (mesma refeição)
      const itensDoSlot = dia.itens.filter(i => i.tipo_refeicao_id === itemAtual.tipo_refeicao_id)
      const sortedSlot = sortItensByRefeicao(itensDoSlot, tiposRefeicao)
      const idxAtual = sortedSlot.findIndex(i => i.id === itemId)
      if (idxAtual === -1) continue

      const idxTroca = direcao === 'up' ? idxAtual - 1 : idxAtual + 1
      if (idxTroca < 0 || idxTroca >= sortedSlot.length) return // já está no extremo

      const itemTroca = sortedSlot[idxTroca]

      // Se todos têm ordem 0, atribui ordens sequenciais a TODOS antes de trocar
      const todosZero = sortedSlot.every(i => (i.ordem ?? 0) === 0)
      const ordensMap: Record<string, number> = {}
      if (todosZero) {
        sortedSlot.forEach((item, idx) => {
          ordensMap[item.id] = idx + 1
        })
      } else {
        sortedSlot.forEach((item) => {
          ordensMap[item.id] = item.ordem ?? 0
        })
      }

      // Troca as ordens dos dois itens
      const temp = ordensMap[itemId]
      ordensMap[itemId] = ordensMap[itemTroca.id]
      ordensMap[itemTroca.id] = temp

      // Atualização otimista: aplica todas as ordens localmente
      setCardapio(prev => {
        if (!prev) return prev
        return {
          ...prev,
          semanas: prev.semanas.map(s => ({
            ...s,
            dias: s.dias.map(d => ({
              ...d,
              itens: d.itens.map(i => {
                if (ordensMap[i.id] !== undefined) {
                  return { ...i, ordem: ordensMap[i.id] }
                }
                return i
              }),
            })),
          })),
        }
      })

      // Envia para a API (sem esperar para não travar a UI)
      try {
        await fetch(`/api/nutricao/cardapios/${cardapioId}/reordenar-item`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ item_id: itemId, direcao }),
        })
      } catch {
        toast.error('Erro ao salvar ordem')
      }
      return
    }
  }

  // Get percapita-adjusted gramas for an ingredient based on cardápio's fase_escolar
  function getGramasForFase(ing: IngredienteComAlimento): number {
    if (!cardapio) return ing.quantidade_gramas
    if (ing.mesma_percapita) return ing.quantidade_gramas
    const percapita = ing.percapitas?.find(p => p.fase_escolar === cardapio.fase_escolar)
    if (percapita) return percapita.quantidade_gramas
    return calcularPercapitaPorFase(ing.quantidade_gramas, cardapio.fase_escolar as FaseEscolar)
  }

  // v9.9.4: kcal por porção da preparação (usa a fase escolar do cardápio)
  // Mesma convenção do resumo nutricional: Σ (gramas da fase × energia_kcal do alimento / 100)
  function kcalPreparacao(p: Preparacao): number {
    return p.ingredientes.reduce((soma, ing) => {
      const gramas = getGramasForFase(ing)
      return soma + (gramas * (ing.alimento.energia_kcal || 0)) / 100
    }, 0)
  }

  // Calculate nutritional summary for current week
  const resumoNutricional = useMemo((): ResumoNutricionalSemana | null => {
    if (!semanaAtual || !cardapio) return null

    const diasNutrientes: NutrienteDia[] = []
    for (const dia of semanaAtual.dias) {
      const diaNutri = dia.itens.reduce<NutrienteDia>((acc, item) => {
        const refeicaoNutri = calcularNutrientesRefeicao([{
          preparacao: {
            ingredientes: item.preparacao.ingredientes.map((ing) => ({
              quantidade_gramas: getGramasForFase(ing),
              alimento: ing.alimento,
            })),
          },
          porcoes: item.porcoes,
        }])
        return somarNutrientes(acc, refeicaoNutri)
      }, emptyNutrienteDia())
      diasNutrientes.push(diaNutri)
    }

    const meta = metas.find((m) => m.categoria_escola === cardapio.categoria_escola)
    if (!meta) {
      return {
        media_dia: diasNutrientes.length > 0 ? diasNutrientes.reduce(somarNutrientes, emptyNutrienteDia()) : emptyNutrienteDia(),
        alertas: [],
        dias_com_ferro_heme: 0,
        dias_com_vitamina_a: 0,
        percentuais: { carboidratos_pct: 0, proteinas_pct: 0, lipidios_pct: 0, acucar_pct: 0 },
      }
    }

    return calcularResumoSemana(diasNutrientes, {
      energia_kcal_min: meta.energia_kcal_min,
      energia_kcal_max: meta.energia_kcal_max,
      carboidratos_pct_min: meta.carboidratos_pct_min,
      carboidratos_pct_max: meta.carboidratos_pct_max,
      proteinas_pct_min: meta.proteinas_pct_min,
      proteinas_pct_max: meta.proteinas_pct_max,
      lipidios_pct_min: meta.lipidios_pct_min,
      lipidios_pct_max: meta.lipidios_pct_max,
      sodio_mg_max: meta.sodio_mg_max,
      ferro_mg_min: meta.ferro_mg_min,
      ferro_heme_dias_semana: meta.ferro_heme_dias_semana,
      vitamina_a_mcg_min: meta.vitamina_a_mcg_min,
      vitamina_a_dias_semana: meta.vitamina_a_dias_semana,
      vitamina_c_mg_min: meta.vitamina_c_mg_min,
      acucar_pct_max: meta.acucar_pct_max,
      acucar_proibido_menor3: meta.acucar_proibido_menor3,
    }, cardapio.categoria_escola)
  }, [semanaAtual, cardapio, metas])

  // Open add dialog for a specific slot
  // v9.9.4: agora abre em "modo editar" se o slot já tiver preparações —
  // elas aparecem pré-selecionadas (desmarcar + salvar remove do cardápio).
  function openAddDialog(diaId: string, tipoRefeicaoId: string) {
    setAddDiaId(diaId)
    setAddTipoRefeicaoId(tipoRefeicaoId)
    setAddPrepSearch('')
    setAddFilter('all')
    setAddFilterCategoria('all')
    setAddSemAlergenos(new Set())

    const dia = semanaAtual?.dias.find(d => d.id === diaId)
    const itensSlot = dia ? dia.itens.filter(i => i.tipo_refeicao_id === tipoRefeicaoId) : []
    setAddExistingItems(new Map(itensSlot.map(i => [i.preparacao_id, i.id])))
    setAddSelectedPrepIds(new Set(itensSlot.map(i => i.preparacao_id)))

    setAddDialogOpen(true)
  }

  // v9.9.4: diff do modo editar — o que será adicionado e o que será removido ao salvar
  const addNovasPreparacoes = Array.from(addSelectedPrepIds).filter(id => !addExistingItems.has(id))
  const addItensParaRemover = Array.from(addExistingItems.entries())
    .filter(([prepId]) => !addSelectedPrepIds.has(prepId))
    .map(([, itemId]) => itemId)

  // Toggle preparation selection
  function togglePrepSelection(prepId: string) {
    setAddSelectedPrepIds(prev => {
      const next = new Set(prev)
      if (next.has(prepId)) next.delete(prepId)
      else next.add(prepId)
      return next
    })
  }

  // v9.10.17: escolher preparação com a barra de busca preenchida limpa a busca
  // e devolve o cursor ao campo — pronto para digitar a próxima (ex.: "pão" →
  // escolheu → já digita "suco"). Desmarcar NÃO limpa (mantém o filtro atual).
  function togglePrepSelectionComBusca(prepId: string) {
    const estavaSelecionada = addSelectedPrepIds.has(prepId)
    togglePrepSelection(prepId)
    if (!estavaSelecionada && addPrepSearch.trim()) {
      setAddPrepSearch('')
      requestAnimationFrame(() => addPrepSearchRef.current?.focus())
    }
  }

  // v9.9.4: salva o slot sincronizando a seleção —
  // adiciona as marcadas que não existem e remove as pré-existentes que foram desmarcadas.
  async function handleAddPreparacoes() {
    if (!addDiaId) return
    if (addNovasPreparacoes.length === 0 && addItensParaRemover.length === 0) {
      setAddDialogOpen(false)
      return
    }
    setAdding(true)
    try {
      const alvoDiaId = addDiaId
      let itensCriados: CardapioItem[] = []

      // 1) Adicionar novas preparações (batch)
      if (addNovasPreparacoes.length > 0) {
        const items = addNovasPreparacoes.map(prepId => ({
          dia_id: alvoDiaId,
          tipo_refeicao_id: addTipoRefeicaoId,
          preparacao_id: prepId,
          porcoes: 1,
        }))
        const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/item`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ items }),
        })
        if (!res.ok) {
          const errData = await res.json().catch(() => ({}))
          throw new Error(errData.error || 'Erro ao adicionar preparações')
        }
        const criados = await res.json()
        itensCriados = (Array.isArray(criados) ? criados : [criados]) as CardapioItem[]
      }

      // 2) Remover preparações desmarcadas
      if (addItensParaRemover.length > 0) {
        const delResults = await Promise.all(addItensParaRemover.map(itemId =>
          fetch(`/api/nutricao/cardapios/${cardapioId}/item`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ item_id: itemId }),
          })
        ))
        if (delResults.some(r => !r.ok)) throw new Error('Erro ao remover preparações')
      }

      // 3) Feedback dinâmico
      const partes: string[] = []
      if (itensCriados.length > 0) partes.push(`${itensCriados.length} adicionada(s)`)
      if (addItensParaRemover.length > 0) partes.push(`${addItensParaRemover.length} removida(s)`)
      toast.success(`Refeição atualizada: ${partes.join(' · ')}`)
      setAddDialogOpen(false)

      // ── ATUALIZAÇÃO OTIMISTA (sem refresh) ──
      const idsRemovidos = new Set(addItensParaRemover)
      setCardapio(prev => {
        if (!prev) return prev
        return {
          ...prev,
          semanas: prev.semanas.map(s => ({
            ...s,
            dias: s.dias.map(d => {
              const restantes = d.itens.filter(i => !idsRemovidos.has(i.id))
              if (d.id !== alvoDiaId) return { ...d, itens: restantes }
              return { ...d, itens: [...restantes, ...itensCriados] }
            }),
          })),
        }
      })

      // 4) Marca semana como diferenciada quando houve remoção (cardápio instância)
      if (addItensParaRemover.length > 0 && cardapio?.escola_id && cardapio?.cardapio_base_id) {
        handleDiferenciarSemana(currentSemana, true)
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erro ao salvar preparações')
    } finally {
      setAdding(false)
    }
  }

  // ── v8: Abrir/fechar sub-dialog de preparação (nova ou editar) ──
  // Chamado a partir do dialog "Adicionar Preparações" — não abre nova aba.
  function openEditPrepInDialog(prepId: string) {
    setEditingPrepInDialog(prepId)
    setPrepDialogOpenInCardapio(true)
  }
  function openNewPrepInDialog() {
    setEditingPrepInDialog(null)
    setPrepDialogOpenInCardapio(true)
  }
  // Recarrega apenas a lista de preparações (após criar/editar no sub-dialog)
  async function refreshPreparacoes() {
    try {
      const [prepRes, topRes] = await Promise.all([
        fetch('/api/nutricao/preparacoes'),
        fetch('/api/nutricao/preparacoes?recentes=true&limite_recentes=6'),
      ])
      if (prepRes.ok) {
        const data = await prepRes.json()
        setPreparacoes(Array.isArray(data) ? data : [])
      }
      if (topRes.ok) {
        const top = await topRes.json()
        setTopPreparacoes(Array.isArray(top) ? top : [])
      }
    } catch {
      // silencioso — não bloqueia o fluxo
    }
  }
  function handlePrepSaved(info: { id: string; nome: string; isNew: boolean }) {
    refreshPreparacoes()
    // Seleciona automaticamente a preparação recém-criada para fácil adição
    if (info.isNew) {
      setAddSelectedPrepIds(prev => new Set(prev).add(info.id))
      toast.success(`Preparação "${info.nome}" criada e pré-selecionada`)
    } else {
      toast.success(`Preparação "${info.nome}" atualizada`)
    }
  }
  // v8: Após clonar — muda editingPrepId para a nova prep e mantém o dialog aberto
  // (o usuário continua editando a cópia sem sair da página)
  function handlePrepCloned(newId: string, clonedPrep: PreparacaoLite) {
    setEditingPrepInDialog(newId)
    // Atualização otimista: adiciona a nova prep à lista IMEDIATAMENTE
    // para que o `editingPrep` prop seja encontrado sem flash de formulário vazio.
    // O refreshPreparacoes abaixo vai buscar a versão canônica do banco.
    setPreparacoes(prev => [
      clonedPrep as unknown as Preparacao,
      ...prev.filter(p => p.id !== newId),
    ])
    // Também atualiza topPreparacoes (não afeta a cópia, mas mantém consistência)
    refreshPreparacoes()
  }
  // v8: Após excluir — fecha dialog e recarrega lista (a prep excluída some)
  function handlePrepDeleted(_id: string) {
    refreshPreparacoes()
    // Remove da seleção caso estivesse selecionada
    setAddSelectedPrepIds(prev => {
      const next = new Set(prev)
      next.delete(_id)
      return next
    })
  }

  // ── v8.7: Horário customizado de refeição ──
  // Abre o dialog de edição de horário para uma refeição
  function openHorarioDialog(tipoRefeicaoId: string, nomeRefeicao: string, horarioDefault: string, horarioAtual: string) {
    setHorarioEditando({ tipoRefeicaoId, nome: nomeRefeicao, horarioDefault, horarioAtual })
    setHorarioInput(horarioAtual || horarioDefault)
    setHorarioDialogOpen(true)
  }

  // Salva o horário customizado (POST na API)
  async function handleSaveHorario() {
    if (!horarioEditando) return
    if (!horarioInput.trim()) {
      toast.error('Horário não pode ser vazio')
      return
    }
    setSalvandoHorario(true)
    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/horarios`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tipo_refeicao_id: horarioEditando.tipoRefeicaoId,
          horario: horarioInput.trim(),
        }),
      })
      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err.error || 'Erro ao salvar horário')
      }
      const saved = await res.json()
      // Atualização otimista: atualiza o estado do cardápio
      setCardapio(prev => {
        if (!prev) return prev
        const existing = prev.horarios_refeicoes || []
        const others = existing.filter(h => h.tipo_refeicao_id !== horarioEditando.tipoRefeicaoId)
        return {
          ...prev,
          horarios_refeicoes: [
            ...others,
            { id: saved.id, cardapio_id: prev.id, tipo_refeicao_id: horarioEditando.tipoRefeicaoId, horario: saved.horario, multiplicador: saved.multiplicador },
          ],
        }
      })
      toast.success(`Horário de "${horarioEditando.nome}" atualizado para ${saved.horario}`)
      setHorarioDialogOpen(false)
      setHorarioEditando(null)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erro ao salvar horário')
    } finally {
      setSalvandoHorario(false)
    }
  }

  // Remove o override (volta a usar o default de TipoRefeicao)
  async function handleResetHorario() {
    if (!horarioEditando) return
    setSalvandoHorario(true)
    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/horarios?tipo_refeicao_id=${horarioEditando.tipoRefeicaoId}`, {
        method: 'DELETE',
      })
      if (!res.ok) throw new Error('Erro ao remover horário')
      // Atualização otimista
      setCardapio(prev => {
        if (!prev) return prev
        return {
          ...prev,
          horarios_refeicoes: (prev.horarios_refeicoes || []).filter(h => h.tipo_refeicao_id !== horarioEditando.tipoRefeicaoId),
        }
      })
      toast.success(`Horário de "${horarioEditando.nome}" restaurado para o padrão (${horarioEditando.horarioDefault})`)
      setHorarioDialogOpen(false)
      setHorarioEditando(null)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erro ao remover horário')
    } finally {
      setSalvandoHorario(false)
    }
  }

  async function handleRemoveItem(itemId: string) {
    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/item`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ item_id: itemId }),
      })
      if (!res.ok) throw new Error('Erro ao remover preparação')
      toast.success('Preparação removida')

      // ── ATUALIZAÇÃO OTIMISTA (sem refresh) ──
      setCardapio(prev => {
        if (!prev) return prev
        return {
          ...prev,
          semanas: prev.semanas.map(s => ({
            ...s,
            dias: s.dias.map(d => ({
              ...d,
              itens: d.itens.filter(i => i.id !== itemId),
            })),
          })),
        }
      })

      // v8: marca semana atual como diferenciada (se for cardápio de escola)
      if (cardapio?.escola_id && cardapio?.cardapio_base_id) {
        handleDiferenciarSemana(currentSemana, true)
      }
    } catch {
      toast.error('Erro ao remover preparação')
    }
  }

  // Remove all items from a slot (refeição in a day)
  async function handleClearSlot(diaSemana: string, tipoRefeicaoId: string) {
    if (!semanaAtual) return
    const dia = semanaAtual.dias.find(d => d.dia_semana === diaSemana)
    if (!dia) return
    const itens = dia.itens.filter(i => i.tipo_refeicao_id === tipoRefeicaoId)
    if (itens.length === 0) return

    try {
      await Promise.all(itens.map(item =>
        fetch(`/api/nutricao/cardapios/${cardapioId}/item`, {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ item_id: item.id }),
        })
      ))
      toast.success('Refeição limpa')

      // ── ATUALIZAÇÃO OTIMISTA (sem refresh) ──
      const itemIds = new Set(itens.map(i => i.id))
      setCardapio(prev => {
        if (!prev) return prev
        return {
          ...prev,
          semanas: prev.semanas.map(s => ({
            ...s,
            dias: s.dias.map(d => ({
              ...d,
              itens: d.itens.filter(i => !itemIds.has(i.id)),
            })),
          })),
        }
      })

      // v8: marca semana atual como diferenciada
      if (cardapio?.escola_id && cardapio?.cardapio_base_id) {
        handleDiferenciarSemana(currentSemana, true)
      }
    } catch {
      toast.error('Erro ao limpar refeição')
    }
  }

  // ── NOVO v7: Quick-add (1-clique) para preparação universal ──
  async function handleQuickAdd(prepId: string, diaId: string, tipoRefeicaoId: string, prepNome?: string) {
    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/item`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dia_id: diaId,
          tipo_refeicao_id: tipoRefeicaoId,
          preparacao_id: prepId,
          porcoes: 1,
        }),
      })
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}))
        throw new Error(errData.error || 'Erro ao adicionar')
      }
      const itemCriado = await res.json()
      toast.success(`${prepNome || 'Preparação'} adicionada`)

      // ── ATUALIZAÇÃO OTIMISTA (sem refresh) ──
      // Encontra a preparação completa no estado `preparacoes` (já carregada)
      const prepCompleta = preparacoes.find(p => p.id === prepId)
      if (prepCompleta) {
        setCardapio(prev => {
          if (!prev) return prev
          return {
            ...prev,
            semanas: prev.semanas.map(s => ({
              ...s,
              dias: s.dias.map(d => {
                if (d.id !== diaId) return d
                // Adiciona o novo item (ou atualiza porções se já existia)
                const existente = d.itens.find(i => i.tipo_refeicao_id === tipoRefeicaoId && i.preparacao_id === prepId)
                if (existente) {
                  return {
                    ...d,
                    itens: d.itens.map(i => i.id === existente.id ? { ...i, porcoes: i.porcoes + 1 } : i),
                  }
                }
                return {
                  ...d,
                  itens: [...d.itens, {
                    id: itemCriado.id || `temp-${Date.now()}`,
                    tipo_refeicao_id: tipoRefeicaoId,
                    preparacao_id: prepId,
                    porcoes: 1,
                    tipo_refeicao: tiposRefeicao.find(t => t.id === tipoRefeicaoId) || { id: tipoRefeicaoId, nome: '', horario: '', ordem: 0, codigo: '' },
                    preparacao: prepCompleta,
                  }],
                }
              }),
            })),
          }
        })
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erro ao adicionar preparação')
    }
  }

  // v8: Porções não são mais editáveis inline — definidas no cadastro da preparação.
  // Função handleUpdatePorcoes removida.

  // ── NOVO v8: Marcar semana como diferenciada (manualmente ajustada vs base) ──
  // v9.9.6: parâmetro silencioso (sem toast) para marcação em lote via substituição
  async function handleDiferenciarSemana(semanaNumero: number, marcarComoDiferenciada?: boolean, silencioso?: boolean) {
    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/diferenciar-semana`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          semana_numero: semanaNumero,
          diferenciada: marcarComoDiferenciada,
        }),
      })
      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err.error || 'Erro ao marcar semana')
      }
      const data = await res.json()
      // Atualização otimista local
      setCardapio(prev => {
        if (!prev) return prev
        return {
          ...prev,
          semanas: prev.semanas.map(s =>
            s.numero === semanaNumero
              ? { ...s, diferenciada: data.diferenciada }
              : s
          ),
        }
      })
      if (!silencioso) toast.success(data.message)
    } catch (err) {
      if (!silencioso) toast.error(err instanceof Error ? err.message : 'Erro ao diferenciar semana')
      else console.error('Erro silencioso ao diferenciar semana', semanaNumero, err)
    }
  }

  // ── v9.9.6: Localizar e Substituir — handlers ──
  function openSubDialog() {
    setSubBusca('')
    setSubResultados(null)
    setSubPrepSelecionada(null)
    setSubItensMarcados(new Set())
    setSubNovaId('')
    setSubNovaBusca('')
    setSubNovaAberta(false)
    setSubExecutando(false)
    setSubDialogOpen(true)
  }

  // ── v9.9.7: Localizar — abrir dialog (estado limpo) ──
  function openLocDialog() {
    setLocBusca('')
    setLocResultados(null)
    setLocPrepAberta(null)
    setLocBuscando(false)
    setLocDialogOpen(true)
  }

  // ── v9.9.7: Localizar — "Ir" para a ocorrência ──
  // Fecha o dialog, pula para a semana (e dia no mobile), rola até o item e o
  // destaca com ring âmbar por alguns segundos. Timers são limpos se o usuário
  // navegar de novo antes (evita o destaque piscar/apagar cedo demais).
  function irParaOcorrencia(o: SubOcorrencia) {
    if (locClearTimerRef.current) clearTimeout(locClearTimerRef.current)
    if (locScrollTimerRef.current) clearTimeout(locScrollTimerRef.current)
    setCurrentSemana(o.semana_num)
    if (isMobile) setMobileDayView(o.dia_semana)
    setLocDestaqueItemId(o.item_id)
    setLocDialogOpen(false)
    // Aguarda o React re-renderizar a semana nova antes de rolar até o item
    locScrollTimerRef.current = setTimeout(() => {
      document.getElementById(`cardapio-item-${o.item_id}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' })
    }, 250)
    locClearTimerRef.current = setTimeout(() => setLocDestaqueItemId(null), 6000)
  }

  // ── v9.9.9: Analisador de Repetições — abrir dialog (estado limpo) ──
  function openRepDialog() {
    setRepCardAberto(null)
    setRepCat('all')
    setRepSoAlertas(true)
    setRepDialogOpen(true)
  }

  // ── v9.10.0: Gerar Ciclo — chama a API, recarrega as semanas e fecha ──
  // A API detecta o ciclo pelo conteúdo, deleta semanas além do ciclo e recria
  // ciclo+1..22 como réplicas (S7=S1 ...). Sem $transaction longa (pgbouncer).
  async function handleGerarCiclo() {
    setGerandoCiclo(true)
    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/gerar-ciclo`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      })
      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err.error || 'Erro ao gerar ciclo')
      }
      const data = await res.json()
      const substituidas: number[] = data.semanas_substituidas_com_conteudo || []
      toast.success(
        `Ciclo gerado: ${data.semanas_geradas} semanas criadas (S${String((data.ciclo_semanas || 0) + 1).padStart(2, '0')}–S${String(data.total_semanas).padStart(2, '0')}) repetindo o ciclo de ${data.ciclo_semanas} semanas`
      )
      if (substituidas.length > 0) {
        toast.warning(`Semanas ${substituidas.map((n: number) => `S${n}`).join(', ')} tinham conteúdo e foram substituídas pelo ciclo.`)
      }
      setCicloDialogOpen(false)
      await loadData() // recarrega as 22 semanas do banco (operação em massa)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erro ao gerar ciclo')
    } finally {
      setGerandoCiclo(false)
    }
  }

  function toggleSubItem(itemId: string) {
    setSubItensMarcados(prev => {
      const next = new Set(prev)
      if (next.has(itemId)) next.delete(itemId)
      else next.add(itemId)
      return next
    })
  }

  // Aplica localmente o resultado de substituir_um (atualizado | deletado_duplicata)
  function aplicarSubstituicaoLocal(itemId: string, nova: Preparacao, deletado: boolean) {
    setCardapio(prev => {
      if (!prev) return prev
      return {
        ...prev,
        semanas: prev.semanas.map(s => ({
          ...s,
          dias: s.dias.map(d => {
            if (!d.itens.some(i => i.id === itemId)) return d
            if (deletado) return { ...d, itens: d.itens.filter(i => i.id !== itemId) }
            return {
              ...d,
              itens: d.itens.map(i =>
                i.id === itemId ? { ...i, preparacao_id: nova.id, preparacao: nova } : i
              ),
            }
          }),
        })),
      }
    })
  }

  // Marca semanas afetadas como diferenciada (apenas instâncias de base), sem spam de toast
  async function marcarSemanasSubstituidas(numeros: number[]) {
    if (!cardapio?.escola_id || !cardapio?.cardapio_base_id) return
    for (const n of numeros) {
      await handleDiferenciarSemana(n, true, true)
    }
  }

  async function handleSubstituir() {
    if (!subPrepSelecionada || !subNovaId || subItensMarcados.size === 0) return
    const prepNova = preparacoes.find(p => p.id === subNovaId)
    if (!prepNova) return
    if (prepNova.id === subPrepSelecionada.preparacao_id) {
      toast.error('A preparação substituta é igual à original')
      return
    }

    // Lote = todas as ocorrências marcadas → 1 requisição (substituir_todos);
    // Parcial = loop de substituir_um apenas nas marcadas
    const modoLote = subItensMarcados.size === subPrepSelecionada.ocorrencias.length
    setSubExecutando(true)
    try {
      if (modoLote) {
        const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/localizar-substituir`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            acao: 'substituir_todos',
            preparacao_id_antiga: subPrepSelecionada.preparacao_id,
            preparacao_id_nova: subNovaId,
          }),
        })
        if (!res.ok) {
          const err = await res.json().catch(() => ({}))
          throw new Error(err.error || 'Erro ao substituir')
        }
        const data = await res.json()
        const semanasAfetadas = [...new Set(subPrepSelecionada.ocorrencias.map(o => o.semana_num))]
        await marcarSemanasSubstituidas(semanasAfetadas)
        await loadData() // recarrega do banco (operação em massa tocou várias semanas)
        toast.success(
          `Substituição concluída: ${data.atualizados} atualizada(s)` +
          (data.duplicatas_removidas > 0 ? ` · ${data.duplicatas_removidas} removida(s) (substituta já estava na refeição)` : '')
        )
      } else {
        let atualizadas = 0
        let removidas = 0
        const semanasAfetadas = new Set<number>()
        for (const o of subPrepSelecionada.ocorrencias) {
          if (!subItensMarcados.has(o.item_id)) continue
          const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/localizar-substituir`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ acao: 'substituir_um', item_id: o.item_id, preparacao_id_nova: subNovaId }),
          })
          if (!res.ok) {
            const err = await res.json().catch(() => ({}))
            throw new Error(err.error || 'Erro ao substituir')
          }
          const data = await res.json()
          semanasAfetadas.add(o.semana_num)
          if (data.acao === 'deletado_duplicata') removidas++
          else atualizadas++
          aplicarSubstituicaoLocal(o.item_id, prepNova, data.acao === 'deletado_duplicata')
        }
        await marcarSemanasSubstituidas([...semanasAfetadas])
        toast.success(
          `Substituição concluída: ${atualizadas} atualizada(s)` +
          (removidas > 0 ? ` · ${removidas} removida(s) (substituta já estava na refeição)` : '')
        )
      }
      setSubDialogOpen(false)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erro ao substituir preparação')
    } finally {
      setSubExecutando(false)
    }
  }

  // ── NOVO v7: Mover item via drag-and-drop ──
  async function handleMoveItem(item: CardapioItem, destinoSemana: number, destinoDia: string, destinoTipoRefeicaoId: string) {
    // Não faz nada se for o mesmo slot
    const semanaOrigem = cardapio?.semanas.find(s => s.dias.some(d => d.itens.some(i => i.id === item.id)))
    const diaOrigem = semanaOrigem?.dias.find(d => d.itens.some(i => i.id === item.id))
    if (semanaOrigem?.numero === destinoSemana && diaOrigem?.dia_semana === destinoDia && item.tipo_refeicao_id === destinoTipoRefeicaoId) {
      return
    }

    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/mover-item`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          item_id: item.id,
          destino: {
            semana_numero: destinoSemana,
            dia_semana: destinoDia,
            tipo_refeicao_id: destinoTipoRefeicaoId,
          },
        }),
      })
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}))
        throw new Error(errData.error || 'Erro ao mover')
      }
      const data = await res.json()
      toast.success(`Movido para ${destinoDia}, semana ${destinoSemana}${data.action === 'merged' ? ' (mesclada com item existente)' : ''}`)

      // ── ATUALIZAÇÃO OTIMISTA (sem refresh) ──
      // IMPORTANTE: a API DELETE o item original e CRIA um novo item no destino
      // (com NOVO id). Precisamos usar o novo id retornado em data.item.id,
      // senão na próxima vez que o usuário tentar mover o mesmo item, o front
      // vai enviar o id ANTIGO (que não existe mais) → 404.
      const novoItemId = data.item?.id || item.id
      const novoItem: CardapioItem = {
        ...item,
        id: novoItemId,
        tipo_refeicao_id: destinoTipoRefeicaoId,
      }

      setCardapio(prev => {
        if (!prev) return prev
        return {
          ...prev,
          semanas: prev.semanas.map(s => {
            const isSemanaDestino = s.numero === destinoSemana

            return {
              ...s,
              dias: s.dias.map(d => {
                // Remove o item de qualquer dia onde ele esteja (origem) — usa id antigo
                const filteredItens = d.itens.filter(i => i.id !== item.id)

                // Se este é o dia destino, adiciona o item com novo id
                if (isSemanaDestino && d.dia_semana === destinoDia) {
                  if (data.action === 'merged') {
                    // Mesclou com item existente — não re-adiciona (origem já foi removida)
                    return { ...d, itens: filteredItens }
                  }
                  return {
                    ...d,
                    itens: [...filteredItens, novoItem],
                  }
                }
                return { ...d, itens: filteredItens }
              }),
            }
          }),
        }
      })

      // v8: marca a semana destino e origem como diferenciadas (se for cardápio de escola)
      if (cardapio?.escola_id && cardapio?.cardapio_base_id) {
        handleDiferenciarSemana(destinoSemana, true)
        if (semanaOrigem && semanaOrigem.numero !== destinoSemana) {
          handleDiferenciarSemana(semanaOrigem.numero, true)
        }
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erro ao mover preparação')
    }
  }

  // ── v9.10.2: Modo Troca — troca duas preparações de lugar ──
  // Fluxo: botão ⇄ no cabeçalho do dia ativa o modo → clique na 1ª preparação
  // → clique na 2ª → a API troca o conteúdo dos dois itens (preparação +
  // porções) mantendo dia/refeição/ordem de cada posição. ESC ou ✕ cancela.
  function sairModoTroca() {
    setModoTroca(false)
    setTrocaPrimeiro(null)
  }

  async function handleTrocaClick(item: CardapioItem) {
    if (trocando) return
    // 1º clique: guarda a preparação e pede a 2ª
    if (!trocaPrimeiro) {
      setTrocaPrimeiro(item)
      toast.info(`1ª preparação: ${item.preparacao.nome} — agora clique na 2ª para trocar de lugar`)
      return
    }
    // Clique na mesma preparação: desmarca (cancela a seleção sem sair do modo)
    if (trocaPrimeiro.id === item.id) {
      setTrocaPrimeiro(null)
      toast.info('Seleção cancelada — clique na 1ª preparação novamente')
      return
    }

    setTrocando(true)
    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/trocar-itens`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ item_a_id: trocaPrimeiro.id, item_b_id: item.id }),
      })
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}))
        throw new Error(errData.error || 'Erro ao trocar preparações')
      }
      const data = await res.json()
      const nomeA = trocaPrimeiro.preparacao.nome
      const nomeB = item.preparacao.nome

      // ── Atualização otimista (sem refresh) ──
      // action 'swapped' → os dois itens trocam de conteúdo (preparacao_id,
      //                    objeto preparacao e porções) — ids preservados
      // action 'ordem'   → mesmo slot: troca apenas os valores de ordem
      const trocaConteudos = new Map<string, Partial<CardapioItem>>([
        [trocaPrimeiro.id, { preparacao_id: item.preparacao_id, preparacao: item.preparacao, porcoes: item.porcoes }],
        [item.id, { preparacao_id: trocaPrimeiro.preparacao_id, preparacao: trocaPrimeiro.preparacao, porcoes: trocaPrimeiro.porcoes }],
      ])

      setCardapio(prev => {
        if (!prev) return prev
        return {
          ...prev,
          semanas: prev.semanas.map(s => ({
            ...s,
            dias: s.dias.map(d => ({
              ...d,
              itens: d.itens.map(i => {
                if (data.action === 'ordem') {
                  if (i.id === trocaPrimeiro.id) return { ...i, ordem: data.ordem_a }
                  if (i.id === item.id) return { ...i, ordem: data.ordem_b }
                  return i
                }
                const troca = trocaConteudos.get(i.id)
                return troca ? { ...i, ...troca } : i
              }),
            })),
          })),
        }
      })

      toast.success(
        data.action === 'ordem'
          ? `Ordem trocada: ${nomeA} ⇄ ${nomeB}`
          : `Trocadas de lugar: ${nomeA} ⇄ ${nomeB}`
      )

      // v8: marca a semana como diferenciada (se for cardápio de escola)
      if (cardapio?.escola_id && cardapio?.cardapio_base_id) {
        handleDiferenciarSemana(currentSemana, true)
      }

      sairModoTroca()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erro ao trocar preparações')
    } finally {
      setTrocando(false)
    }
  }

  // ── v9.10.3: Modo Trocar Dia — troca o DIA INTEIRO de lugar ──
  // Fluxo: botão 📅⇄ no cabeçalho de um dia ativa o modo COM esse dia já
  // pré-selecionado como 1º → clique no cabeçalho (ou botão 📅⇄) de outro
  // dia → a API troca TODAS as preparações entre os dois dias. ESC ou ✕
  // cancela; clicar no mesmo dia de novo desmarca a seleção.
  const diaLabel = (v: string) => DIAS_SEMANA_NUTRI.find(d => d.value === v)?.label || v

  function sairModoTrocaDia() {
    setModoTrocaDia(false)
    setTrocaDiaPrimeiro(null)
  }

  function handleDiaHeaderClick(diaValue: string) {
    if (trocandoDia) return
    // Modo inativo: ativa com o dia clicado já pré-selecionado (1º dia)
    if (!modoTrocaDia) {
      sairModoTroca()
      setModoTrocaDia(true)
      setTrocaDiaPrimeiro(diaValue)
      toast.info(`1º dia: ${diaLabel(diaValue)} — agora clique no 2º dia para trocar tudo de lugar`)
      return
    }
    // Clique no mesmo dia: desmarca (cancela a seleção sem sair do modo)
    if (trocaDiaPrimeiro === diaValue) {
      setTrocaDiaPrimeiro(null)
      toast.info('Seleção cancelada — clique no 1º dia novamente')
      return
    }
    // Modo ativo sem 1º dia selecionado: o clique passa a ser o 1º dia
    if (!trocaDiaPrimeiro) {
      setTrocaDiaPrimeiro(diaValue)
      toast.info(`1º dia: ${diaLabel(diaValue)} — agora clique no 2º dia para trocar tudo de lugar`)
      return
    }
    executarTrocaDia(trocaDiaPrimeiro, diaValue)
  }

  async function executarTrocaDia(diaA: string, diaB: string) {
    setTrocandoDia(true)
    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/trocar-dia`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ semana_numero: currentSemana, dia_a: diaA, dia_b: diaB }),
      })
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}))
        throw new Error(errData.error || 'Erro ao trocar dias')
      }
      const data = await res.json()
      const labelA = diaLabel(diaA)
      const labelB = diaLabel(diaB)

      // A API apaga e recria os itens (ids NOVOS no banco) — recarrega o
      // cardápio para sincronizar os ids locais. Sem isso, uma remoção ou
      // troca de preparação logo após a troca de dia daria 404.
      const cardRes = await fetch(`/api/nutricao/cardapios/${cardapioId}`)
      if (cardRes.ok) {
        setCardapio(await cardRes.json())
      }

      toast.success(
        data.itens_trocados > 0
          ? `Dias trocados: ${labelA} ⇄ ${labelB} (${data.itens_trocados} ${data.itens_trocados === 1 ? 'preparação movida' : 'preparações movidas'})`
          : 'Os dois dias estão vazios — nada para trocar'
      )

      // v8: marca a semana como diferenciada (se for cardápio de escola)
      if (cardapio?.escola_id && cardapio?.cardapio_base_id) {
        handleDiferenciarSemana(currentSemana, true)
      }

      sairModoTrocaDia()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erro ao trocar dias')
    } finally {
      setTrocandoDia(false)
    }
  }

  // ── v9.10.17: Modo Mover Várias — marque quantas preparações quiser e
  // mova TODAS para outro dia de uma vez (cada uma mantém a sua refeição).
  // Fluxo: botão "Mover várias" na barra da semana ativa o modo → cliques
  // nas preparações marcam/desmarcam (anel verde) → clique no cabeçalho do
  // dia de destino → mover-item sequencial (a API mescla duplicatas e
  // devolve action moved/merged) → reload p/ sincronizar os ids novos.
  function sairModoMover() {
    setModoMover(false)
    setMoverSelecionados(new Set())
  }

  function entrarModoMover() {
    sairModoTroca()
    sairModoTrocaDia()
    setModoMover(true)
    setMoverSelecionados(new Set())
  }

  function handleMoverItemClick(item: CardapioItem) {
    if (movendo) return
    setMoverSelecionados(prev => {
      const next = new Set(prev)
      if (next.has(item.id)) next.delete(item.id)
      else next.add(item.id)
      return next
    })
  }

  function handleMoverDestino(diaValue: string) {
    if (movendo) return
    if (moverSelecionados.size === 0) {
      toast.info('Modo mover: primeiro clique nas preparações que quer mover')
      return
    }
    executarMoverVarios(diaValue)
  }

  async function executarMoverVarios(destinoDia: string) {
    if (!semanaAtual || moverSelecionados.size === 0) return

    // Itens marcados com o dia de origem (todos estão na semana visível)
    const itensSelecionados: Array<{ item_id: string; tipo_refeicao_id: string; dia_origem: string; nome: string }> = []
    for (const dia of semanaAtual.dias) {
      for (const item of dia.itens) {
        if (moverSelecionados.has(item.id)) {
          itensSelecionados.push({
            item_id: item.id,
            tipo_refeicao_id: item.tipo_refeicao_id,
            dia_origem: dia.dia_semana,
            nome: item.preparacao.nome,
          })
        }
      }
    }
    const { movimentos, ignoradosMesmoDia } = prepararMovimentos(itensSelecionados, destinoDia, currentSemana)
    if (movimentos.length === 0) {
      toast.info('Nada para mover — as preparações marcadas já estão no dia de destino')
      return
    }

    setMovendo(true)
    let movidos = 0
    let mesclados = 0
    try {
      for (const m of movimentos) {
        const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/mover-item`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            item_id: m.item_id,
            destino: {
              semana_numero: m.semana_numero,
              dia_semana: m.dia_semana,
              tipo_refeicao_id: m.tipo_refeicao_id,
            },
          }),
        })
        if (!res.ok) {
          const errData = await res.json().catch(() => ({}))
          throw new Error(errData.error || 'Erro ao mover')
        }
        const data = await res.json()
        if (data.action === 'merged') mesclados++
        else movidos++
      }

      // A API apaga e recria os itens (ids NOVOS) — recarrega o cardápio para
      // sincronizar os ids locais (mesmo cuidado do executarTrocaDia).
      const cardRes = await fetch(`/api/nutricao/cardapios/${cardapioId}`)
      if (cardRes.ok) setCardapio(await cardRes.json())

      const partes = [
        `${movidos} movida(s)`,
        mesclados > 0 ? `${mesclados} mesclada(s) (já existia na refeição)` : null,
        ignoradosMesmoDia > 0 ? `${ignoradosMesmoDia} já estava(m) no dia de destino` : null,
      ].filter(Boolean)
      toast.success(`Movidas para ${diaLabel(destinoDia)}: ${partes.join(' · ')}`)

      // v8: marca a semana como diferenciada (se for cardápio de escola)
      if (cardapio?.escola_id && cardapio?.cardapio_base_id) {
        handleDiferenciarSemana(currentSemana, true)
      }

      sairModoMover()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erro ao mover preparações')
      // Falha parcial já moveu parte dos itens (ids mudaram) — sincroniza
      try {
        const cardRes = await fetch(`/api/nutricao/cardapios/${cardapioId}`)
        if (cardRes.ok) setCardapio(await cardRes.json())
      } catch { /* silencioso */ }
      sairModoMover()
    } finally {
      setMovendo(false)
    }
  }

  // v8: Duplicar item (Alt+Drag) — cria cópia no destino sem remover origem
  async function handleDuplicateItem(item: CardapioItem, destinoSemana: number, destinoDia: string, destinoTipoRefeicaoId: string) {
    // Não duplica para o mesmo slot — dá feedback claro para o usuário
    const semanaOrigem = cardapio?.semanas.find(s => s.dias.some(d => d.itens.some(i => i.id === item.id)))
    const diaOrigem = semanaOrigem?.dias.find(d => d.itens.some(i => i.id === item.id))
    if (semanaOrigem?.numero === destinoSemana && diaOrigem?.dia_semana === destinoDia && item.tipo_refeicao_id === destinoTipoRefeicaoId) {
      toast.info('Mesmo slot de origem — arraste para outro dia ou refeição para duplicar')
      return
    }

    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/duplicar-item`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          item_id: item.id,
          destino: {
            semana_numero: destinoSemana,
            dia_semana: destinoDia,
            tipo_refeicao_id: destinoTipoRefeicaoId,
          },
        }),
      })
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}))
        throw new Error(errData.error || 'Erro ao duplicar')
      }
      const data = await res.json()
      toast.success(`Duplicado para ${destinoDia}, semana ${destinoSemana}${data.action === 'merged' ? ' (mesclado com item existente)' : ''}`)

      // Atualização otimista
      const novoItemId = data.item?.id || `temp-${Date.now()}`
      setCardapio(prev => {
        if (!prev) return prev
        return {
          ...prev,
          semanas: prev.semanas.map(s => {
            if (s.numero !== destinoSemana) return s
            return {
              ...s,
              dias: s.dias.map(d => {
                if (d.dia_semana !== destinoDia) return d
                if (data.action === 'merged') {
                  // Soma porções no item existente
                  return {
                    ...d,
                    itens: d.itens.map(i =>
                      i.preparacao_id === item.preparacao_id && i.tipo_refeicao_id === destinoTipoRefeicaoId
                        ? { ...i, porcoes: i.porcoes + item.porcoes }
                        : i
                    ),
                  }
                }
                // Adiciona novo item
                return {
                  ...d,
                  itens: [...d.itens, {
                    id: novoItemId,
                    tipo_refeicao_id: destinoTipoRefeicaoId,
                    preparacao_id: item.preparacao_id,
                    porcoes: item.porcoes,
                    ordem: 0,
                    tipo_refeicao: item.tipo_refeicao,
                    preparacao: item.preparacao,
                  }],
                }
              }),
            }
          }),
        }
      })
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erro ao duplicar preparação')
    }
  }

  // ── v8: Helper para verificar se um dia da semana atual é feriado ──
  function getFeriadoDoDia(diaSemanaPt: string): { nome: string; tipo: string } | null {
    if (!semanaAtual || !cardapio) return null
    const diaToIdx: Record<string, number> = {
      'domingo': 0, 'segunda': 1, 'terca': 2, 'quarta': 3,
      'quinta': 4, 'sexta': 5, 'sabado': 6,
    }
    const idxAlvo = diaToIdx[diaSemanaPt]
    if (idxAlvo === undefined) return null
    const offsetDias = idxAlvo - 1
    if (offsetDias < 0 || offsetDias > 4) return null

    const inicio = new Date(semanaAtual.data_inicio + 'T12:00:00')
    const dataDia = new Date(inicio)
    dataDia.setDate(inicio.getDate() + offsetDias)
    const dataIso = dataDia.toISOString().split('T')[0]

    const feriado = feriados.find((f) => f.data === dataIso)
    if (!feriado) return null
    const afetadas = feriado.escolas_afetadas || 'TODAS'
    if (afetadas === 'TODAS') return { nome: feriado.nome, tipo: feriado.tipo }
    const map: Record<string, string[]> = {
      'REGULARES': ['REGULAR'], 'INTEGRAIS': ['INTEGRAL'], 'CRECHES': ['CRECHE'],
      'BIFASICA': ['BIFASICA'], 'INTERIOR': ['INTERIOR'], 'OUTROS': ['OUTROS'],
    }
    if (!(map[afetadas] || [afetadas]).includes(cardapio.categoria_escola)) return null
    return { nome: feriado.nome, tipo: feriado.tipo }
  }

  // ── NOVO v7: Resumo nutricional por dia (para mini-painel) ──
  function getResumoDia(diaSemana: string): { energia: number; ferro_heme: boolean; vit_a: boolean; alertas: number } {
    if (!semanaAtual || !cardapio) return { energia: 0, ferro_heme: false, vit_a: false, alertas: 0 }
    const dia = semanaAtual.dias.find(d => d.dia_semana === diaSemana)
    if (!dia || dia.itens.length === 0) return { energia: 0, ferro_heme: false, vit_a: false, alertas: 0 }

    const diaNutri = dia.itens.reduce<NutrienteDia>((acc, item) => {
      const refeicaoNutri = calcularNutrientesRefeicao([{
        preparacao: {
          ingredientes: item.preparacao.ingredientes.map((ing) => ({
            quantidade_gramas: getGramasForFase(ing),
            alimento: ing.alimento,
          })),
        },
        porcoes: item.porcoes,
      }])
      return somarNutrientes(acc, refeicaoNutri)
    }, emptyNutrienteDia())

    return {
      energia: diaNutri.energia_kcal,
      ferro_heme: diaNutri.ferro_heme_mg > 0,
      vit_a: diaNutri.vitamina_a_mcg > 0,
      alertas: 0,  // simplificado para o mini-resumo
    }
  }

  // Semáforo do dia baseado na energia vs meta
  function getDiaTrafficLight(energia: number): 'gray' | 'red' | 'amber' | 'green' {
    if (energia === 0) return 'gray'
    const meta = metas.find(m => m.categoria_escola === cardapio?.categoria_escola)
    if (!meta) return 'gray'
    if (energia < meta.energia_kcal_min * 0.7) return 'red'
    if (energia < meta.energia_kcal_min) return 'amber'
    if (energia > meta.energia_kcal_max) return 'amber'
    return 'green'
  }

  async function handleSaveFase() {
    if (!cardapio) return
    setSaving(true)
    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fase_escolar: selectedFase }),
      })
      if (!res.ok) throw new Error('Erro ao salvar')
      toast.success('Fase escolar atualizada')
      setFaseDialogOpen(false)
      loadData()
    } catch {
      toast.error('Erro ao salvar fase escolar')
    } finally {
      setSaving(false)
    }
  }

  // v8: Salvar data de início do cardápio
  async function handleSaveDataInicio() {
    if (!cardapio || !dataInicio) return
    setSaving(true)
    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data_inicio: dataInicio }),
      })
      if (!res.ok) throw new Error('Erro ao salvar data')
      toast.success('Datas atualizadas — todas as semanas foram recalculadas')
      setDataInicioDialogOpen(false)
      loadData()
    } catch {
      toast.error('Erro ao salvar data de início')
    } finally {
      setSaving(false)
    }
  }

  // v8: Salvar nome do cardápio
  async function handleSaveNome() {
    if (!cardapio || !editandoNome.trim()) return
    setSaving(true)
    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome: editandoNome.trim() }),
      })
      if (!res.ok) throw new Error('Erro ao salvar nome')
      toast.success('Nome do cardápio atualizado')
      setNomeDialogOpen(false)
      loadData()
    } catch {
      toast.error('Erro ao salvar nome')
    } finally {
      setSaving(false)
    }
  }

  async function handleApprove() {
    if (!cardapio) return
    setSaving(true)
    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'APROVADO' }),
      })
      if (!res.ok) throw new Error('Erro ao aprovar')
      toast.success('Cardápio aprovado')
      loadData()
    } catch {
      toast.error('Erro ao aprovar cardápio')
    } finally {
      setSaving(false)
    }
  }

  // v9.10.17: handleSave removido — o antigo botão "Salvar" do topo só
  // reenviava a fase_escolar JÁ salva pela própria caixa (handleSaveFase),
  // ou seja, não tinha função real. Toda ação da tela salva na hora.

  // v8: Excluir cardápio
  async function handleDeleteCardapio() {
    setDeleting(true)
    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}`, {
        method: 'DELETE',
      })
      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err.error || 'Erro ao excluir')
      }
      toast.success('Cardápio excluído')
      router.push('/nutricao/cardapios')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erro ao excluir cardápio')
    } finally {
      setDeleting(false)
      setDeleteDialogOpen(false)
    }
  }

  // Open copy dialog — pre-select the clicked day
  function openCopyDialog(diaSemana: string, semanaNumero: number) {
    setCopyOrigemSemana(semanaNumero)
    setCopyOrigemDias(new Set([diaSemana]))
    setCopyDestinoSemana(semanaNumero === totalSemanas ? 1 : semanaNumero + 1)
    setCopyDestinoDias(new Set([diaSemana])) // same weekday by default
    setCopyDialogOpen(true)
  }

  // Toggle a day in a Set
  function toggleDiaInSet(dia: string, set: Set<string>, setter: (s: Set<string>) => void) {
    const next = new Set(set)
    if (next.has(dia)) next.delete(dia)
    else next.add(dia)
    setter(next)
  }

  // Select / deselect all weekdays
  function toggleAllDias(set: Set<string>, setter: (s: Set<string>) => void, select: boolean) {
    if (select) {
      setter(new Set(DIAS_SEMANA_NUTRI.map(d => d.value)))
    } else {
      setter(new Set())
    }
  }

  // "Match same days" — sets destination days = origin days
  function matchDestinoToOrigem() {
    setCopyDestinoDias(new Set(copyOrigemDias))
  }

  // v9.10.17: preset "Semana inteira" — marca os 5 dias na origem e no destino.
  // Se a semana destino for a MESMA da origem, pula para a seguinte
  // (origem == destino no mesmo dia daria conflito na cópia).
  function copiarSemanaInteira() {
    setCopyOrigemDias(new Set(DIAS_SEMANA_NUTRI.map(d => d.value)))
    setCopyDestinoDias(new Set(DIAS_SEMANA_NUTRI.map(d => d.value)))
    if (copyDestinoSemana === copyOrigemSemana) {
      setCopyDestinoSemana(copyDestinoSemana >= totalSemanas ? 1 : copyDestinoSemana + 1)
    }
  }

  async function handleCopyDays() {
    // v9.10.17: mapeamento centralizado na lib — par-a-par (N→N) OU
    // um-para-muitos (1 dia de origem → TODOS os destinos marcados).
    const mapa = mapearCopiasDias([...copyOrigemDias], [...copyDestinoDias], copyOrigemSemana, copyDestinoSemana)
    if (mapa.erro || mapa.origens.length === 0) {
      toast.error(mapa.erro || 'Selecione pelo menos um dia de origem e um de destino')
      return
    }

    setCopying(true)
    try {
      const res = await fetch(`/api/nutricao/cardapios/${cardapioId}/copiar-dia`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ origens: mapa.origens, limpar_destino: true }),
      })
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}))
        throw new Error(errData.error || 'Erro ao copiar')
      }
      const result = await res.json()
      toast.success(`${result.total_itens_copiados} preparação(ões) copiada(s) em ${result.dias_copiados} dia(s) — Semana ${copyDestinoSemana}`)
      setCopyDialogOpen(false)
      loadData()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erro ao copiar dias')
    } finally {
      setCopying(false)
    }
  }

  const filteredPreparacoes = useMemo(() => {
    let list = preparacoes

    // Filtro por aba
    if (addFilter === 'favoritas') {
      list = list.filter((p) => p.favorita)
    } else if (addFilter === 'recentes') {
      list = [...list].sort((a, b) => (b.vezes_usada || 0) - (a.vezes_usada || 0)).slice(0, 30)
    }

    // Filtro por alérgenos (excluir)
    if (addSemAlergenos.size > 0) {
      list = list.filter((p) => {
        // v9.6.4: respeita override manual de alergenos
        const bloqueados = parseAlergenosArrayLocal((p as any).alergenos_bloqueados)
        const forcados = parseAlergenosArrayLocal((p as any).alergenos_forcados)
        const alergenos = detectarAlergenosPreparacaoComOverride(
          p.ingredientes.map((ing) => ({
            nome: ing.alimento.nome,
            grupo: ing.alimento.grupo,
          })),
          bloqueados,
          forcados,
        )
        // Se tem QUALQUER alérgeno da lista de exclusão, remover
        return !alergenos.some((a) => addSemAlergenos.has(a))
      })
    }

    // v9.9.4: filtro por categoria da preparação
    if (addFilterCategoria !== 'all') {
      list = list.filter((p) => getCategoriaInfo(p.categoria || 'PREPARACAO').value === addFilterCategoria)
    }

    // Busca por nome (sem acento)
    const q = normalizeText(addPrepSearch)
    if (q) {
      list = list.filter((p) => normalizeText(p.nome).includes(q))
    }

    return list
  }, [preparacoes, addFilter, addSemAlergenos, addFilterCategoria, addPrepSearch])

  // v9.9.4: categorias presentes na biblioteca (com contagem) — para os chips de filtro
  const addCategoriasDisponiveis = useMemo(() => {
    const counts = new Map<string, number>()
    for (const p of preparacoes) {
      const key = getCategoriaInfo(p.categoria || 'PREPARACAO').value
      counts.set(key, (counts.get(key) || 0) + 1)
    }
    return PREPARACAO_CATEGORIAS
      .map(c => ({ ...c, count: counts.get(c.value) || 0 }))
      .filter(c => c.count > 0)
  }, [preparacoes])

  // v9.9.5: preparações selecionadas (já no cardápio + marcadas agora) na ORDEM DA LISTA — exibidas em bloco fixo no topo
  const selecionadasNaOrdem = useMemo(() => {
    return preparacoes.filter(p => addSelectedPrepIds.has(p.id))
  }, [preparacoes, addSelectedPrepIds])

  // v9.9.4: lista agrupada por categoria (ordem canônica) — v9.9.5: exclui as selecionadas (elas ficam no bloco do topo)
  const gruposPreparacoes = useMemo(() => {
    return PREPARACAO_CATEGORIAS
      .map(c => ({
        categoria: c.value,
        label: c.label,
        cor: c.cor,
        itens: filteredPreparacoes.filter(p =>
          !addSelectedPrepIds.has(p.id) &&
          getCategoriaInfo(p.categoria || 'PREPARACAO').value === c.value
        ),
      }))
      .filter(g => g.itens.length > 0)
  }, [filteredPreparacoes, addSelectedPrepIds])

  // v9.9.6: candidatas a substituta (busca local na biblioteca, sem API)
  const subNovasFiltradas = useMemo(() => {
    const q = normalizeText(subNovaBusca)
    let list = preparacoes.filter(p => p.id !== subPrepSelecionada?.preparacao_id)
    if (q) list = list.filter(p => normalizeText(p.nome).includes(q))
    return list.slice(0, 8)
  }, [preparacoes, subNovaBusca, subPrepSelecionada])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full border-2 border-[#D4A017]/30 border-t-[#D4A017] animate-spin" />
          <span className="text-muted-foreground">Carregando cardápio...</span>
        </div>
      </div>
    )
  }

  if (error || !cardapio) {
    return (
      <div className="text-center py-12">
        <p className="text-sm text-red-500 mb-3">{error || 'Cardápio não encontrado.'}</p>
        <Button variant="outline" size="sm" onClick={loadData}>
          <RefreshCw className="w-3 h-3 mr-1" /> Tentar novamente
        </Button>
      </div>
    )
  }

  const totalSemanas = cardapio.semanas.length || 22
  const faseInfo = FASES_ESCOLARES.find(f => f.value === cardapio.fase_escolar)

  // v9.10.17: pré-visualização do mapeamento de cópia (par-a-par ou 1→N) —
  // recalculado a cada render com os estados atuais do dialog
  const mapaCopia = mapearCopiasDias([...copyOrigemDias], [...copyDestinoDias], copyOrigemSemana, copyDestinoSemana)

  // v9.9.5: render de uma linha de preparação — usado no bloco "Selecionadas" (topo) e nos grupos por categoria
  const renderPrepRow = (p: Preparacao) => {
    // v9.6.4: respeita override manual de alergenos
    const bloqueados = parseAlergenosArrayLocal((p as any).alergenos_bloqueados)
    const forcados = parseAlergenosArrayLocal((p as any).alergenos_forcados)
    const alergenos = detectarAlergenosPreparacaoComOverride(
      p.ingredientes.map((ing) => ({
        nome: ing.alimento.nome,
        grupo: ing.alimento.grupo,
      })),
      bloqueados,
      forcados,
    )
    // v9.9.4: kcal por porção + flag "já estava no cardápio"
    const kcal = Math.round(kcalPreparacao(p))
    const jaNoCardapio = addExistingItems.has(p.id)
    return (
      <label
        key={p.id}
        onClick={(e) => {
          // v9.9.4: linha inteira clicável para marcar/desmarcar
          // v9.10.17: ao SELECIONAR, limpa a busca e devolve o foco ao campo
          e.preventDefault()
          togglePrepSelectionComBusca(p.id)
        }}
        className={`flex items-center gap-1.5 px-2 py-1.5 rounded-md cursor-pointer transition-colors text-xs ${
          addSelectedPrepIds.has(p.id)
            ? 'bg-[#1A3A5C]/10 border border-[#1A3A5C]/20'
            : 'hover:bg-gray-50 border border-transparent'
        }`}
      >
        <Checkbox
          checked={addSelectedPrepIds.has(p.id)}
          className="flex-shrink-0 pointer-events-none"
        />
        {p.favorita && (
          <Star className="w-3 h-3 text-[#D4A017] flex-shrink-0 fill-[#D4A017]" />
        )}
        <span className="font-medium truncate flex-1 min-w-0" title={p.nome}>{p.nome}</span>
        {jaNoCardapio && (
          <span
            className="px-1 py-0.5 rounded bg-amber-50 border border-amber-200 text-[8px] font-bold text-amber-700 flex-shrink-0 whitespace-nowrap"
            title="Já está nesta refeição — desmarque para remover"
          >
            no cardápio
          </span>
        )}
        {alergenos.length > 0 && (
          <div className="flex items-center gap-0.5 flex-shrink-0">
            {alergenos.map((sigla) => (
              <span
                key={sigla}
                className="inline-flex items-center justify-center w-4 h-4 rounded-sm border border-gray-300 text-[8px] font-bold text-gray-600"
                title={sigla}
              >
                {sigla}
              </span>
            ))}
          </div>
        )}
        {/* v9.9.5: cluster compacto kcal · ingredientes · usos — não é cortado pela largura da janela */}
        <span className="flex items-center gap-1 text-[9px] flex-shrink-0 whitespace-nowrap">
          <span
            className="flex items-center gap-0.5 text-orange-500 font-medium"
            title={`≈ ${kcal} kcal por porção (fase ${faseInfo?.label || 'atual'})`}
          >
            <Flame className="w-2.5 h-2.5" />
            {kcal} kcal
          </span>
          <span className="text-muted-foreground" title={`${p.ingredientes.length} ingrediente(s)`}>
            · {p.ingredientes.length} ing.
          </span>
          {p.vezes_usada > 0 && (
            <span className="text-muted-foreground" title={`Usada ${p.vezes_usada}× no semestre`}>
              · {p.vezes_usada}×
            </span>
          )}
        </span>
        {/* v8: Botão editar preparação — abre sub-dialog (não abre nova aba) */}
        <button
          type="button"
          onClick={(e) => {
            e.preventDefault()
            e.stopPropagation()
            openEditPrepInDialog(p.id)
          }}
          className="text-blue-500 hover:text-blue-700 hover:bg-blue-50 rounded p-0.5 flex-shrink-0 transition-colors"
          title="Editar preparação"
        >
          <Pencil className="w-3 h-3" />
        </button>
      </label>
    )
  }

  return (
    <div className="space-y-3 max-w-[1600px] mx-auto">
      {/* v8: Banner de dica Alt+Drag = duplicar (somente durante o arrasto) */}
      {dragAltHint && (
        <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 bg-[#1A3A5C] text-white text-xs px-4 py-2 rounded-full shadow-lg flex items-center gap-2 animate-pulse">
          <Copy className="w-3.5 h-3.5" />
          <span>Solte para <b className="font-bold">mover</b> · segure <kbd className="px-1.5 py-0.5 bg-white/20 rounded text-[10px] font-mono">Alt</kbd> para <b className="font-bold">duplicar</b></span>
        </div>
      )}
      {/* v9.10.2: Banner do Modo Troca (ativo enquanto a ferramenta ⇄ está ligada) */}
      {modoTroca && (
        <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 bg-violet-600 text-white text-xs px-4 py-2 rounded-full shadow-lg flex items-center gap-2">
          <ArrowLeftRight className="w-3.5 h-3.5 flex-shrink-0" />
          {trocando ? (
            <span>Trocando preparações...</span>
          ) : trocaPrimeiro ? (
            <span>1ª: <b className="font-bold">{trocaPrimeiro.preparacao.nome}</b> — agora clique na 2ª preparação</span>
          ) : (
            <span><b className="font-bold">Modo troca:</b> clique na 1ª e depois na 2ª preparação — elas trocam de lugar</span>
          )}
          <button
            onClick={sairModoTroca}
            className="ml-1 w-4 h-4 rounded-full bg-white/20 hover:bg-white/40 flex items-center justify-center flex-shrink-0"
            title="Cancelar modo troca (ESC)"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}
      {/* v9.10.3: Banner do Modo Trocar Dia (troca o dia inteiro de lugar) */}
      {modoTrocaDia && (
        <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 bg-indigo-600 text-white text-xs px-4 py-2 rounded-full shadow-lg flex items-center gap-2">
          <CalendarSync className="w-3.5 h-3.5 flex-shrink-0" />
          {trocandoDia ? (
            <span>Trocando dias...</span>
          ) : trocaDiaPrimeiro ? (
            <span>1º dia: <b className="font-bold">{diaLabel(trocaDiaPrimeiro)}</b> — agora clique no 2º dia (no cabeçalho azul)</span>
          ) : (
            <span><b className="font-bold">Modo trocar dia:</b> clique no cabeçalho do 1º dia e depois no 2º — tudo troca de lugar</span>
          )}
          <button
            onClick={sairModoTrocaDia}
            className="ml-1 w-4 h-4 rounded-full bg-white/20 hover:bg-white/40 flex items-center justify-center flex-shrink-0"
            title="Cancelar modo trocar dia (ESC)"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}
      {/* v9.10.17: Banner do Modo Mover Várias (marque N preparações → dia de destino) */}
      {modoMover && (
        <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 bg-emerald-600 text-white text-xs px-4 py-2 rounded-full shadow-lg flex items-center gap-2">
          <MousePointerClick className="w-3.5 h-3.5 flex-shrink-0" />
          {movendo ? (
            <span>Movendo preparações...</span>
          ) : moverSelecionados.size > 0 ? (
            <span><b className="font-bold">{moverSelecionados.size}</b> marcada(s) — agora clique no cabeçalho do <b className="font-bold">dia de destino</b></span>
          ) : (
            <span><b className="font-bold">Modo mover:</b> clique nas preparações (marque várias) e depois no dia de destino — todas movem juntas</span>
          )}
          <button
            onClick={sairModoMover}
            className="ml-1 w-4 h-4 rounded-full bg-white/20 hover:bg-white/40 flex items-center justify-center flex-shrink-0"
            title="Cancelar modo mover (ESC)"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}
      {/* Top Bar */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-white p-3 rounded-xl border border-[#1A3A5C]/10 shadow-sm"
      >
        <div className="flex items-center gap-3">
          <Link href="/nutricao/cardapios">
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <h1
                className="text-lg font-bold text-[#1A3A5C] truncate cursor-pointer hover:text-blue-700 hover:underline"
                onClick={() => {
                  setEditandoNome(cardapio.nome)
                  setNomeDialogOpen(true)
                }}
                title="Clique para editar o nome do cardápio"
              >
                {cardapio.nome}
              </h1>
              {getStatusBadge(cardapio.status)}
            </div>
            <p className="text-xs text-muted-foreground">
              {cardapio.escola?.nome || 'Modelo base'} · {cardapio.ano}/{cardapio.semestre}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* Fase escolar badge */}
          <button
            onClick={() => setFaseDialogOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs font-medium transition-colors hover:bg-gray-50"
            style={{ borderColor: faseInfo?.cor || '#1A3A5C', color: faseInfo?.cor || '#1A3A5C' }}
          >
            <Users className="w-3 h-3" />
            {faseInfo?.label || cardapio.fase_escolar}
            <span className="text-[10px] opacity-70">({faseInfo?.faixa || '—'})</span>
          </button>

          {/* v8: Botão Configurar Datas */}
          <button
            onClick={() => {
              // Pega a data da primeira semana como default
              const primeiraSemana = cardapio.semanas?.[0]
              if (primeiraSemana?.data_inicio) {
                setDataInicio(primeiraSemana.data_inicio)
              }
              setDataInicioDialogOpen(true)
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs font-medium transition-colors hover:bg-gray-50 border-blue-300 text-blue-700"
            title="Configurar data de início do cardápio"
          >
            <Calendar className="w-3 h-3" />
            {cardapio.semanas?.[0]?.data_inicio ? formatDate(cardapio.semanas[0].data_inicio) : 'Definir data'}
          </button>

          {/* v9.9.8: Replicar p/ Escolas disponível para TODOS os cardápios (base e escola).
              A API (v8.10) já exclui a escola de origem e preserva o vínculo com o base. */}
          <Link href={`/nutricao/cardapios/${cardapioId}/replicar`}>
            <Button variant="outline" size="sm" className="text-xs h-8 border-purple-200 text-purple-700 hover:bg-purple-50" title="Replicar este cardápio e suas semanas para outras escolas, escolhendo o dia de pão/lanche de cada uma">
              <Copy className="w-3 h-3 mr-1" /> Replicar p/ Escolas
            </Button>
          </Link>

          {/* v9.10.17: Botão "Comparar c/ Base" removido do editor (a comparação
              continua disponível na lista de cardápios, página /comparar) */}

          {/* Botão Clonar em Lote (somente se for base) — mantido para compat. */}
          {!cardapio.escola_id && (
            <Link href={`/nutricao/cardapios/${cardapioId}/clonar-lote`}>
              <Button variant="outline" size="sm" className="text-xs h-8 border-emerald-200 text-emerald-700 hover:bg-emerald-50">
                <Layers className="w-3 h-3 mr-1" /> Clonar em Lote
              </Button>
            </Link>
          )}

          {/* v9.9.7: Localizar e Substituir separados (funções independentes) */}
          <Button
            variant="outline"
            size="sm"
            className="text-xs h-8 border-blue-200 text-blue-700 hover:bg-blue-50"
            onClick={openLocDialog}
            title="Localizar preparação no cardápio e ir até a semana (somente consulta)"
          >
            <Search className="w-3 h-3 mr-1" /> Localizar
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="text-xs h-8 border-amber-300 text-amber-700 hover:bg-amber-50"
            onClick={openSubDialog}
            title="Localizar uma preparação e substituí-la parcial ou totalmente por outra"
          >
            <Replace className="w-3 h-3 mr-1" /> Substituir
          </Button>

          {/* v9.10.17: Analisador de Repetições movido para JUNTO DO RESUMO
              NUTRICIONAL (sidebar) — botão pequeno no cabeçalho do resumo */}

          {/* v9.10.0: Gerar Ciclo — repete as semanas montadas até completar as 22 do semestre */}
          <Button
            variant="outline"
            size="sm"
            className="text-xs h-8 border-teal-200 text-teal-700 hover:bg-teal-50"
            onClick={() => setCicloDialogOpen(true)}
            title="Repete as semanas preenchidas até completar o semestre: ex. 6 semanas montadas viram 22 (S7=S1, S8=S2...)"
          >
            <Repeat className="w-3 h-3 mr-1" /> Gerar Ciclo
          </Button>

          <Button variant="outline" size="sm" className="lg:hidden" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            <span className="ml-1 text-xs">Resumo</span>
          </Button>
          <Link href={`/nutricao/cardapios/${cardapioId}/pdf`}>
            <Button variant="outline" size="sm" className="text-xs">
              <FileText className="w-3 h-3 mr-1" /> PDF
            </Button>
          </Link>
          {cardapio.status === 'RASCUNHO' && (
            <Button variant="outline" size="sm" className="text-xs text-emerald-600 border-emerald-200 hover:bg-emerald-50" onClick={handleApprove} disabled={saving}>
              <CheckCircle className="w-3 h-3 mr-1" /> Aprovar
            </Button>
          )}
          {/* v9.10.17: botão "Salvar" removido — toda ação da tela já salva na
              hora (não existe estado pendente aqui); o manual de ajuda explica */}
          {/* v9.10.17: Ajuda — manual visual completo de como usar o editor */}
          <Button
            variant="outline"
            size="sm"
            className="text-xs h-8 border-gray-300 text-gray-600 hover:bg-gray-50"
            onClick={() => setAjudaDialogOpen(true)}
            title="Manual de uso do editor de cardápio"
          >
            <HelpCircle className="w-3 h-3 mr-1" /> Ajuda
          </Button>
          <Button
            size="sm"
            onClick={() => setDeleteDialogOpen(true)}
            disabled={deleting}
            className="bg-red-600 hover:bg-red-700 text-xs"
            title="Excluir este cardápio permanentemente"
          >
            <Trash2 className="w-3 h-3 mr-1" /> Excluir
          </Button>
        </div>
      </motion.div>

      {/* Week Navigation */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="flex items-center justify-between bg-white p-2 rounded-xl border border-[#1A3A5C]/10"
      >
        <Button variant="ghost" size="sm" onClick={() => setCurrentSemana(Math.max(1, currentSemana - 1))} disabled={currentSemana <= 1}>
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-[#1A3A5C]">Semana {currentSemana}</span>
          {/* v8: Badge "Modificada" quando semana foi diferenciada vs base */}
          {semanaAtual?.diferenciada && (
            <Badge className="bg-[#D4A017]/10 text-[#D4A017] border-[#D4A017]/30 text-[9px]" title="Esta semana foi manualmente ajustada vs o cardápio base">
              <Unlock className="w-2.5 h-2.5 mr-0.5" /> Modificada
            </Badge>
          )}
          {semanaAtual && (
            <span className="text-xs text-muted-foreground">
              ({formatDate(semanaAtual.data_inicio)} — {formatDate(semanaAtual.data_fim)})
            </span>
          )}
          {/* v8: Botão "Diferenciar Semana" — só para cardápios de escola (instâncias de base) */}
          {cardapio.escola_id && cardapio.cardapio_base_id && semanaAtual && (
            <Button
              variant="ghost"
              size="sm"
              className="h-6 text-[10px] text-[#D4A017] hover:bg-[#D4A017]/10 ml-2"
              onClick={() => handleDiferenciarSemana(currentSemana)}
              title={semanaAtual.diferenciada
                ? "Restaurar como cópia do base (mas mantém as alterações feitas)"
                : "Marcar esta semana como modificada vs o cardápio base"
              }
            >
              <Unlock className="w-3 h-3 mr-0.5" />
              {semanaAtual.diferenciada ? 'Restaurar' : 'Diferenciar'}
            </Button>
          )}
          {/* v9.10.17: Modo Mover Várias — marque N preparações e mova todas p/ outro dia */}
          <button
            onClick={() => modoMover ? sairModoMover() : entrarModoMover()}
            className={`inline-flex items-center gap-1 px-2 py-1 rounded-md border text-[10px] font-medium transition-colors ml-2 flex-shrink-0 ${
              modoMover
                ? 'bg-emerald-600 border-emerald-600 text-white'
                : 'border-emerald-200 text-emerald-700 hover:bg-emerald-50'
            }`}
            title="Marque várias preparações e clique no dia de destino — todas movem de uma vez (ESC cancela)"
          >
            <MousePointerClick className="w-3 h-3" />
            {modoMover ? 'Cancelar mover' : 'Mover várias'}
          </button>
          {/* Legenda semáforo */}
          <div className="hidden md:flex items-center gap-2 ml-3 pl-3 border-l border-gray-200">
            <span className="text-[9px] text-muted-foreground">Semáforo:</span>
            <span className="flex items-center gap-1 text-[9px]"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> OK</span>
            <span className="flex items-center gap-1 text-[9px]"><span className="w-1.5 h-1.5 rounded-full bg-amber-400" /> Abaixo/Acima</span>
            <span className="flex items-center gap-1 text-[9px]"><span className="w-1.5 h-1.5 rounded-full bg-red-400" /> Crítico</span>
          </div>
        </div>
        <Button variant="ghost" size="sm" onClick={() => setCurrentSemana(Math.min(totalSemanas, currentSemana + 1))} disabled={currentSemana >= totalSemanas}>
          <ChevronRight className="w-4 h-4" />
        </Button>
      </motion.div>

      {/* Refeições Schedule Bar */}
      {refeicoesForCategoria.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.15 }}
          className="flex items-center gap-3 bg-white p-2.5 rounded-xl border border-[#1A3A5C]/10 overflow-x-auto"
        >
          <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1A3A5C] flex-shrink-0">
            <Clock className="w-3.5 h-3.5" />
            Horários:
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {refeicoesForCategoria.map((cr) => (
              <div key={cr.tipo_refeicao_id} className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-gray-50 border border-gray-100 text-xs">
                <span className="font-medium text-[#1A3A5C]">{cr.tipo_refeicao.nome}</span>
                {/* v8.7: usa horário efetivo (override se existir) */}
                <Badge
                  variant="outline"
                  className={`text-[9px] h-4 px-1 ${
                    (cr as { horario_override?: unknown }).horario_override
                      ? 'border-[#D4A017]/50 text-[#D4A017] bg-[#D4A017]/10'
                      : 'border-[#1A3A5C]/20'
                  }`}
                >
                  {(cr as { horario_efetivo?: string }).horario_efetivo ?? cr.tipo_refeicao.horario}
                </Badge>
                <span className="text-[9px] text-muted-foreground">{cr.percentual_energia}% VET</span>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Main Content */}
      <div className="flex gap-3">
        {/* Grid: 5 columns for days */}
        <div className="flex-1 min-w-0">
          {/* ── NOVO v7: Mobile day picker (apenas 1 dia por vez em telas pequenas) ── */}
          {isMobile && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="lg:hidden mb-2 bg-white p-1.5 rounded-xl border border-[#1A3A5C]/10 flex items-center gap-1 overflow-x-auto"
            >
              <Smartphone className="w-3.5 h-3.5 text-[#1A3A5C] flex-shrink-0 ml-1" />
              {DIAS_SEMANA_NUTRI.map((d) => {
                const isActive = mobileDayView === d.value
                const resumo = getResumoDia(d.value)
                const semaforo = getDiaTrafficLight(resumo.energia)
                return (
                  <button
                    key={d.value}
                    onClick={() => setMobileDayView(d.value)}
                    className={`px-2.5 py-1 rounded-md text-[10px] font-medium flex items-center gap-1 flex-shrink-0 transition-colors ${
                      isActive
                        ? 'bg-[#1A3A5C] text-white'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <span className={`w-1.5 h-1.5 rounded-full ${
                      semaforo === 'green' ? 'bg-emerald-400' :
                      semaforo === 'amber' ? 'bg-amber-400' :
                      semaforo === 'red' ? 'bg-red-400' : 'bg-gray-300'
                    }`} />
                    {d.label}
                  </button>
                )
              })}
            </motion.div>
          )}

          {/* ── NOVO v7: Quick-add chips bar (top 6 mais usadas) ── */}
          {topPreparacoes.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-2 bg-white p-2 rounded-xl border border-[#1A3A5C]/10"
            >
              <div className="flex items-center gap-2 flex-wrap">
                <div className="flex items-center gap-1 text-[10px] font-semibold text-[#1A3A5C] flex-shrink-0">
                  <Zap className="w-3 h-3 text-[#D4A017]" />
                  1-clique:
                </div>
                {topPreparacoes.map((p) => {
                  // Dia alvo: no mobile usa mobileDayView, no desktop usa a primeira refeição da primeira segunda
                  const diaAlvo = isMobile ? mobileDayView : 'segunda'
                  const diaDataAlvo = semanaAtual?.dias.find(d => d.dia_semana === diaAlvo)
                  const primeiraRefeicao = refeicoesForCategoria[0]
                  return (
                    <button
                      key={p.id}
                      onClick={() => {
                        if (diaDataAlvo && primeiraRefeicao) {
                          handleQuickAdd(p.id, diaDataAlvo.id, primeiraRefeicao.tipo_refeicao_id, p.nome)
                          if (!isMobile) {
                            toast.info(`Adicionado em ${diaAlvo}/${primeiraRefeicao.tipo_refeicao.nome} — arraste para mover`)
                          }
                        } else {
                          toast.error('Semana sem dias configurados')
                        }
                      }}
                      className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-[#1A3A5C]/5 border border-[#1A3A5C]/20 text-[#1A3A5C] hover:bg-[#1A3A5C]/10 transition-colors flex items-center gap-1"
                      title={`Adicionar "${p.nome}" em ${diaAlvo}/${primeiraRefeicao?.tipo_refeicao.nome || ''} — depois arraste para o dia desejado`}
                    >
                      <Plus className="w-2.5 h-2.5" />
                      {p.nome}
                      {p.vezes_usada > 0 && (
                        <span className="text-[8px] text-muted-foreground">({p.vezes_usada}×)</span>
                      )}
                    </button>
                  )
                })}
              </div>
            </motion.div>
          )}

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className={`grid gap-2 ${isMobile ? 'grid-cols-1' : 'grid-cols-1 md:grid-cols-5'}`}
          >
            {DIAS_SEMANA_NUTRI.filter(d => !isMobile || d.value === mobileDayView).map((dia) => {
              const diaData = semanaAtual?.dias.find((d) => d.dia_semana === dia.value)
              const resumoDia = getResumoDia(dia.value)
              const semaforo = getDiaTrafficLight(resumoDia.energia)
              return (
                <div
                  key={dia.value}
                  className={`bg-white rounded-xl border overflow-hidden transition-all ${
                    trocaDiaPrimeiro === dia.value
                      ? 'border-violet-400 ring-2 ring-violet-300'
                      : modoTrocaDia
                        ? 'border-violet-200'
                        : modoMover
                          ? 'border-emerald-300 ring-1 ring-emerald-200'
                          : 'border-gray-200'
                  }`}
                >
                  {/* Day Header with Copy button + traffic-light dot
                      v9.10.3: no Modo Trocar Dia o cabeçalho inteiro é clicável
                      v9.10.17: no Modo Mover Várias o cabeçalho é o DESTINO */}
                  <div
                    onClick={
                      modoTrocaDia
                        ? () => handleDiaHeaderClick(dia.value)
                        : modoMover
                          ? () => handleMoverDestino(dia.value)
                          : undefined
                    }
                    className={`text-white py-1.5 px-2 flex items-center justify-between transition-colors ${
                      trocaDiaPrimeiro === dia.value
                        ? `bg-violet-700 ${(modoTrocaDia || modoMover) ? 'cursor-pointer hover:bg-violet-600' : ''}`
                        : modoTrocaDia
                          ? 'bg-[#1A3A5C] cursor-pointer hover:bg-violet-700'
                          : modoMover
                            ? 'bg-[#1A3A5C] cursor-pointer hover:bg-emerald-700'
                            : 'bg-[#1A3A5C]'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span className={`w-2 h-2 rounded-full flex-shrink-0 ${
                        semaforo === 'green' ? 'bg-emerald-400' :
                        semaforo === 'amber' ? 'bg-amber-400' :
                        semaforo === 'red' ? 'bg-red-400' : 'bg-gray-400'
                      }`} title={`Energia: ${resumoDia.energia.toFixed(0)} kcal`} />
                      <span className="text-xs font-semibold">{dia.label}</span>
                      {/* v8: Badge de feriado */}
                      {(() => {
                        const feriado = getFeriadoDoDia(dia.value)
                        return feriado ? (
                          <span className="ml-1 inline-flex items-center gap-0.5 px-1 py-0 rounded bg-red-500/30 border border-red-400/50 text-[8px] text-red-100 font-bold flex-shrink-0" title={`Feriado: ${feriado.nome}`}>
                            <CalendarOff className="w-2 h-2" />
                            <span className="truncate max-w-[60px]">{feriado.nome}</span>
                          </span>
                        ) : null
                      })()}
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {/* v9.10.2: Trocar preparações — clique em 2 e elas trocam de lugar
                          v9.10.3: no Modo Trocar Dia fica inerte (clique cai no cabeçalho = seleciona o dia)
                          v9.10.17: idem no Modo Mover Várias */}
                      <button
                        onClick={() => { if (modoTroca) { sairModoTroca() } else { sairModoMover(); sairModoTrocaDia(); setModoTroca(true); setTrocaPrimeiro(null) } }}
                        className={`transition-colors ${modoTroca ? 'text-violet-300 hover:text-violet-200' : (modoTrocaDia || modoMover) ? 'text-white/40 pointer-events-none' : 'text-white/70 hover:text-white'}`}
                        title="Trocar preparações: clique em uma, depois em outra — elas trocam de lugar"
                      >
                        <ArrowLeftRight className="w-3 h-3" />
                      </button>
                      {/* v9.10.3: Trocar o DIA inteiro — clique aqui, depois em outro dia */}
                      <button
                        onClick={(e) => { e.stopPropagation(); handleDiaHeaderClick(dia.value) }}
                        className={`transition-colors flex-shrink-0 ${modoTrocaDia ? 'text-indigo-200 hover:text-white' : modoMover ? 'text-white/40 pointer-events-none' : 'text-white/70 hover:text-white'}`}
                        title="Trocar o dia inteiro: clique aqui, depois em outro dia — todas as preparações trocam de lugar"
                      >
                        <CalendarSync className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => openCopyDialog(dia.value, currentSemana)}
                        className={`transition-colors flex-shrink-0 ${(modoTrocaDia || modoMover) ? 'text-white/40 pointer-events-none' : 'text-white/70 hover:text-white'}`}
                        title="Copiar refeições para outro dia"
                      >
                        <Copy className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  {/* Refeição slots */}
                  <div className="p-1.5 space-y-1.5">
                    {refeicoesForCategoria.map((cr) => {
                      const itens = getItensForSlot(dia.value, cr.tipo_refeicao_id)
                      const slotKey = `${dia.value}-${cr.tipo_refeicao_id}`
                      const isDragOver = dragOverSlot === slotKey
                      return (
                        <div
                          key={cr.tipo_refeicao_id}
                          className={`border rounded-lg p-1.5 bg-gray-50/50 transition-colors ${
                            isDragOver
                              ? 'border-[#D4A017] bg-[#D4A017]/5 ring-1 ring-[#D4A017]/30'
                              : 'border-gray-100'
                          }`}
                          onDragOver={(e) => {
                            e.preventDefault()
                            // ⚠️ Importante: usar 'copyMove' para permitir tanto move quanto copy
                            // (setar apenas 'move' faz o navegador bloquear o cursor de cópia com Alt)
                            e.dataTransfer.dropEffect = e.altKey ? 'copy' : 'move'
                            if (!isDragOver) setDragOverSlot(slotKey)
                          }}
                          onDragLeave={() => {
                            if (dragOverSlot === slotKey) setDragOverSlot(null)
                          }}
                          onDrop={(e) => {
                            e.preventDefault()
                            setDragOverSlot(null)
                            if (draggedItem) {
                              // Alt+Drop = duplicar (cópia); Drop normal = mover
                              if (e.altKey) {
                                handleDuplicateItem(draggedItem, currentSemana, dia.value, cr.tipo_refeicao_id)
                              } else {
                                handleMoveItem(draggedItem, currentSemana, dia.value, cr.tipo_refeicao_id)
                              }
                              setDraggedItem(null)
                              setDragAltHint(false)
                            }
                          }}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-[10px] font-semibold text-[#1A3A5C] truncate">{cr.tipo_refeicao.nome}</span>
                            <div className="flex items-center gap-1">
                              {/* v8.7: Badge de horário clicável (mostra override se existir) */}
                              <button
                                onClick={() => openHorarioDialog(
                                  cr.tipo_refeicao_id,
                                  cr.tipo_refeicao.nome,
                                  cr.tipo_refeicao.horario,
                                  (cr as { horario_efetivo?: string }).horario_efetivo ?? cr.tipo_refeicao.horario,
                                )}
                                className={`text-[8px] h-4 px-1 inline-flex items-center gap-0.5 rounded border transition-colors ${
                                  (cr as { horario_override?: unknown }).horario_override
                                    ? 'bg-[#D4A017]/15 border-[#D4A017]/50 text-[#D4A017]'
                                    : 'bg-transparent border-gray-200 text-gray-600 hover:border-[#1A3A5C]/40 hover:text-[#1A3A5C]'
                                }`}
                                title={`Horário padrão: ${cr.tipo_refeicao.horario}. Clique para editar.`}
                              >
                                <ClockIcon className="w-2.5 h-2.5" />
                                {(cr as { horario_efetivo?: string }).horario_efetivo ?? cr.tipo_refeicao.horario}
                              </button>
                              {itens.length > 0 && (
                                <button
                                  onClick={() => handleClearSlot(dia.value, cr.tipo_refeicao_id)}
                                  className="text-red-300 hover:text-red-500 transition-colors"
                                  title="Limpar refeição"
                                >
                                  <Trash2 className="w-2.5 h-2.5" />
                                </button>
                              )}
                            </div>
                          </div>
                          {/* Preparações list com drag handle + porções inline */}
                          {itens.map((item) => (
                            <div
                              key={item.id}
                              id={`cardapio-item-${item.id}`}
                              draggable={!modoTroca && !modoTrocaDia && !modoMover}
                              onClick={
                                modoTroca
                                  ? () => handleTrocaClick(item)
                                  : modoMover
                                    ? () => handleMoverItemClick(item)
                                    : undefined
                              }
                              onDragStart={(e) => {
                                setDraggedItem(item)
                                // ⚠️ 'copyMove' permite que o navegador mostre cursor de cópia (Alt) OU de mover
                                e.dataTransfer.effectAllowed = 'copyMove'
                                // Dica visual temporária para o usuário saber que Alt = duplicar
                                setDragAltHint(true)
                              }}
                              onDragEnd={() => {
                                setDraggedItem(null)
                                setDragOverSlot(null)
                                setDragAltHint(false)
                              }}
                              className={`flex items-center gap-1 mb-1 p-1 rounded bg-white border text-[10px] group transition-all ${
                                modoTroca
                                  ? 'cursor-pointer hover:border-violet-400 hover:bg-violet-50/50'
                                  : modoMover
                                    ? 'cursor-pointer hover:border-emerald-400 hover:bg-emerald-50/50'
                                    : modoTrocaDia
                                      ? 'cursor-default'
                                      : 'cursor-grab active:cursor-grabbing'
                              } ${
                                draggedItem?.id === item.id ? 'opacity-50' :
                                // v9.10.2: 1ª preparação selecionada no Modo Troca
                                trocaPrimeiro?.id === item.id
                                  ? 'border-violet-500 ring-2 ring-violet-300 bg-violet-50'
                                  : // v9.10.17: preparação marcada no Modo Mover Várias
                                  moverSelecionados.has(item.id)
                                    ? 'border-emerald-500 ring-2 ring-emerald-300 bg-emerald-50'
                                    : locDestaqueItemId === item.id ? 'border-amber-400 ring-2 ring-amber-300 bg-amber-50' : 'border-gray-100'
                              }`}
                              title={modoTroca
                                ? (trocaPrimeiro?.id === item.id
                                  ? '1ª selecionada — clique nela novamente para cancelar'
                                  : 'Clique para trocar de lugar com outra preparação')
                                : modoMover
                                  ? (moverSelecionados.has(item.id)
                                    ? 'Marcada para mover — clique para desmarcar'
                                    : 'Clique para marcar; depois clique no cabeçalho do dia de destino')
                                  : modoTrocaDia
                                    ? 'Modo trocar dia ativo — clique no cabeçalho dos dias'
                                    : 'Arraste para mover • Alt+Arraste para duplicar'}
                            >
                              <GripVertical className="w-2.5 h-2.5 text-gray-300 flex-shrink-0 group-hover:text-gray-400" />
                              <span className="flex-1 truncate font-medium">{item.preparacao.nome}</span>
                              {/* v8: Botões up/down para reordenar dentro do slot
                                  (escondidos no Modo Troca — v9.10.2 — e no Modo Mover Várias — v9.10.17) */}
                              {!modoTroca && !modoMover && (
                              <div className="flex flex-col flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button
                                  onClick={(e) => { e.stopPropagation(); handleReordenarItem(item.id, 'up') }}
                                  className="text-gray-300 hover:text-[#1A3A5C] leading-none"
                                  title="Mover para cima"
                                >
                                  <ChevronUp className="w-2.5 h-2.5" />
                                </button>
                                <button
                                  onClick={(e) => { e.stopPropagation(); handleReordenarItem(item.id, 'down') }}
                                  className="text-gray-300 hover:text-[#1A3A5C] leading-none"
                                  title="Mover para baixo"
                                >
                                  <ChevronDown className="w-2.5 h-2.5" />
                                </button>
                              </div>
                              )}
                              {/* Porções (display estático — definidas no cadastro da preparação) */}
                              {item.porcoes > 1 && (
                                <span
                                  className="px-1.5 py-0.5 rounded border border-gray-200 text-[9px] font-bold text-[#1A3A5C] flex-shrink-0"
                                  title={`${item.porcoes} porções`}
                                >
                                  {item.porcoes}×
                                </span>
                              )}
                              {/* v9.10.2: botão remover escondido no Modo Troca (clique = selecionar para troca)
                                  v9.10.17: e no Modo Mover Várias (clique = marcar/desmarcar) */}
                              {!modoTroca && !modoMover && (
                              <button
                                onClick={() => handleRemoveItem(item.id)}
                                className="text-red-300 hover:text-red-500 ml-0.5 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                                title="Remover preparação"
                              >
                                <Trash2 className="w-2.5 h-2.5" />
                              </button>
                              )}
                            </div>
                          ))}
                          {/* Add button */}
                          <Button
                            variant="ghost"
                            size="sm"
                            className="w-full h-5 text-[9px] text-muted-foreground hover:text-[#1A3A5C] hover:bg-[#1A3A5C]/5"
                            onClick={() => {
                              if (diaData) {
                                openAddDialog(diaData.id, cr.tipo_refeicao_id)
                              }
                            }}
                          >
                            <Plus className="w-2.5 h-2.5 mr-0.5" /> Adicionar
                          </Button>
                        </div>
                      )
                    })}
                  </div>

                  {/* ── NOVO v7: Mini-resumo do dia (energia + indicadores) ── */}
                  {resumoDia.energia > 0 && (
                    <div className="px-2 py-1 border-t border-gray-100 bg-gray-50/30 flex items-center justify-between text-[9px]">
                      <span className="text-muted-foreground">
                        {resumoDia.energia.toFixed(0)} kcal
                      </span>
                      <div className="flex items-center gap-1">
                        {resumoDia.ferro_heme && (
                          <span title="Contém ferro heme" className="px-1 py-0.5 rounded bg-red-50 text-red-700 text-[8px] font-bold border border-red-100">Fe-H</span>
                        )}
                        {resumoDia.vit_a && (
                          <span title="Contém Vitamina A" className="px-1 py-0.5 rounded bg-orange-50 text-orange-700 text-[8px] font-bold border border-orange-100">Vit-A</span>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
          </motion.div>
        </div>

        {/* Right Sidebar */}
        {(sidebarOpen || typeof window !== 'undefined') && (
          <div className={`w-80 flex-shrink-0 ${sidebarOpen ? 'block' : 'hidden lg:block'}`}>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card className="border-[#1A3A5C]/10 sticky top-4">
                <CardHeader className="pb-2">
                  {/* v9.10.17: botão "Repetições" agora mora junto do resumo nutricional
                      (sucinto, sem mudar o resto do visual — antes no topo da tela) */}
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-sm font-semibold text-[#1A3A5C]">
                      Resumo Nutricional — Semana {currentSemana}
                    </CardTitle>
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-6 px-1.5 text-[10px] border-indigo-200 text-indigo-700 hover:bg-indigo-50 flex-shrink-0"
                      onClick={openRepDialog}
                      title="Analisador de repetições: 2× no mesmo dia, dias seguidos, dia fixo e variedade por refeição"
                    >
                      <BarChart3 className="w-3 h-3 mr-0.5" /> Repetições
                    </Button>
                  </div>
                  <div className="text-[10px] text-muted-foreground">
                    Cálculo para: <span className="font-medium" style={{ color: faseInfo?.cor || '#1A3A5C' }}>{faseInfo?.label} ({faseInfo?.faixa})</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {resumoNutricional ? (
                    <>
                      {/* Media Dia Table */}
                      <div className="text-[10px] space-y-1">
                        <div className="grid grid-cols-2 gap-x-2 gap-y-0.5">
                          {[
                            { label: 'Energia', value: `${resumoNutricional.media_dia.energia_kcal.toFixed(0)} kcal` },
                            { label: 'Carboidratos', value: `${resumoNutricional.media_dia.carboidratos_g.toFixed(1)} g` },
                            { label: 'Proteínas', value: `${resumoNutricional.media_dia.proteinas_g.toFixed(1)} g` },
                            { label: 'Lipídios', value: `${resumoNutricional.media_dia.lipidios_g.toFixed(1)} g` },
                            { label: 'Fibra', value: `${resumoNutricional.media_dia.fibra_alimentar_g.toFixed(1)} g` },
                            { label: 'Sódio', value: `${resumoNutricional.media_dia.sodio_mg.toFixed(0)} mg` },
                            { label: 'Ferro', value: `${resumoNutricional.media_dia.ferro_mg.toFixed(1)} mg` },
                            { label: 'Vit A', value: `${resumoNutricional.media_dia.vitamina_a_mcg.toFixed(0)} mcg` },
                            { label: 'Vit C', value: `${resumoNutricional.media_dia.vitamina_c_mg.toFixed(1)} mg` },
                          ].map((row) => (
                            <div key={row.label} className="flex justify-between">
                              <span className="text-muted-foreground">{row.label}</span>
                              <span className="font-medium text-[#1A3A5C]">{row.value}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Percentuais */}
                      <div className="border-t pt-2 space-y-1.5">
                        <p className="text-[10px] font-semibold text-muted-foreground uppercase">Percentuais VET</p>
                        {[
                          { label: 'Carboidratos', pct: resumoNutricional.percentuais.carboidratos_pct, color: 'bg-blue-500' },
                          { label: 'Proteínas', pct: resumoNutricional.percentuais.proteinas_pct, color: 'bg-red-500' },
                          { label: 'Lipídios', pct: resumoNutricional.percentuais.lipidios_pct, color: 'bg-yellow-500' },
                          { label: 'Açúcar', pct: resumoNutricional.percentuais.acucar_pct, color: 'bg-pink-500' },
                        ].map((p) => (
                          <div key={p.label}>
                            <div className="flex justify-between text-[10px] mb-0.5">
                              <span className="text-muted-foreground">{p.label}</span>
                              <span className="font-medium">{p.pct.toFixed(1)}%</span>
                            </div>
                            <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                              <div className={`h-full ${p.color} rounded-full transition-all`} style={{ width: `${Math.min(100, p.pct)}%` }} />
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Key Metrics */}
                      <div className="border-t pt-2 grid grid-cols-2 gap-2">
                        <div className="p-2 rounded-lg bg-red-50 border border-red-100">
                          <p className="text-[9px] text-red-600">Ferro Heme</p>
                          <p className="text-sm font-bold text-red-800">{resumoNutricional.dias_com_ferro_heme}/4</p>
                          <p className="text-[8px] text-red-500">dias na semana</p>
                        </div>
                        <div className="p-2 rounded-lg bg-orange-50 border border-orange-100">
                          <p className="text-[9px] text-orange-600">Vitamina A</p>
                          <p className="text-sm font-bold text-orange-800">{resumoNutricional.dias_com_vitamina_a}/3</p>
                          <p className="text-[8px] text-orange-500">dias na semana</p>
                        </div>
                      </div>

                      {/* Alertas PNAE */}
                      <div className="border-t pt-2">
                        <p className="text-[10px] font-semibold text-muted-foreground uppercase mb-1.5">Alertas PNAE</p>
                        {resumoNutricional.alertas.length === 0 ? (
                          <div className="flex items-center gap-1.5 p-2 rounded-lg bg-emerald-50 border border-emerald-100">
                            <CheckCircle className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                            <span className="text-[10px] text-emerald-700">Todos os indicadores OK</span>
                          </div>
                        ) : (
                          <ScrollArea className="max-h-40">
                            <div className="space-y-1">
                              {resumoNutricional.alertas.map((alerta, idx) => (
                                <div key={idx} className={`flex items-start gap-1.5 p-1.5 rounded-lg border ${getAlertaBg(alerta.tipo)}`}>
                                  {getAlertaIcon(alerta.tipo)}
                                  <span className="text-[9px] leading-tight">{alerta.mensagem}</span>
                                </div>
                              ))}
                            </div>
                          </ScrollArea>
                        )}
                      </div>
                    </>
                  ) : (
                    <p className="text-xs text-muted-foreground text-center py-4">Semana sem dados</p>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        )}
      </div>

      {/* ═══ Add Preparações Dialog (Multi-Select) ═══ */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        {/* v9.9.5: sm:max-w-3xl corrige largura real (o sm:max-w-lg do shadcn estava sobrepondo o max-w-2xl e cortava as informações após "ing.") */}
        <DialogContent className="sm:max-w-3xl max-h-[90vh] flex flex-col gap-3 p-5 overflow-hidden">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="text-[#1A3A5C] text-sm">
              {addExistingItems.size > 0 ? 'Editar Preparações da Refeição' : 'Adicionar Preparações'}
            </DialogTitle>
          </DialogHeader>
          <div className="flex-1 min-h-0 flex flex-col gap-2.5 overflow-hidden">
            {/* Abas de filtro rápido */}
            <div className="flex items-center gap-1 bg-gray-100 p-0.5 rounded-md flex-shrink-0">
              <button
                onClick={() => setAddFilter('all')}
                className={`flex-1 flex items-center justify-center gap-1.5 px-2 py-1 rounded text-[10px] font-medium transition-colors ${
                  addFilter === 'all' ? 'bg-white text-[#1A3A5C] shadow-sm' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Search className="w-3 h-3" /> Todas
              </button>
              <button
                onClick={() => setAddFilter('favoritas')}
                className={`flex-1 flex items-center justify-center gap-1.5 px-2 py-1 rounded text-[10px] font-medium transition-colors ${
                  addFilter === 'favoritas' ? 'bg-white text-[#D4A017] shadow-sm' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Star className="w-3 h-3" /> Favoritas
              </button>
              <button
                onClick={() => setAddFilter('recentes')}
                className={`flex-1 flex items-center justify-center gap-1.5 px-2 py-1 rounded text-[10px] font-medium transition-colors ${
                  addFilter === 'recentes' ? 'bg-white text-[#1A3A5C] shadow-sm' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Zap className="w-3 h-3" /> + Usadas
              </button>
            </div>

            {/* v9.9.4: Filtro por categoria (chips com contagem) */}
            <div className="flex items-center gap-1 flex-wrap flex-shrink-0">
              <span className="text-[10px] text-muted-foreground font-medium">Categoria:</span>
              <button
                onClick={() => setAddFilterCategoria('all')}
                className={`px-1.5 py-0.5 rounded text-[9px] font-bold border transition-colors flex items-center gap-1 ${
                  addFilterCategoria === 'all'
                    ? 'bg-[#1A3A5C]/10 border-[#1A3A5C]/40 text-[#1A3A5C]'
                    : 'bg-white border-gray-200 text-gray-500 hover:border-gray-300'
                }`}
              >
                Todas ({preparacoes.length})
              </button>
              {addCategoriasDisponiveis.map((c) => {
                const active = addFilterCategoria === c.value
                return (
                  <button
                    key={c.value}
                    onClick={() => setAddFilterCategoria(active ? 'all' : c.value)}
                    className={`px-1.5 py-0.5 rounded text-[9px] font-bold border transition-colors flex items-center gap-1 ${
                      active
                        ? 'bg-[#1A3A5C]/10 border-[#1A3A5C]/40 text-[#1A3A5C]'
                        : 'bg-white border-gray-200 text-gray-500 hover:border-gray-300'
                    }`}
                    title={c.descricao}
                  >
                    <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: c.cor }} />
                    {c.label} ({c.count})
                  </button>
                )
              })}
            </div>

            {/* Search */}
            <div className="relative flex-shrink-0">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome..."
                value={addPrepSearch}
                onChange={(e) => setAddPrepSearch(e.target.value)}
                className="pl-8 h-8 text-xs"
                ref={addPrepSearchRef}
                autoFocus
              />
            </div>

            {/* Filtro alérgenos (excluir) */}
            <div className="flex items-center gap-1.5 flex-wrap flex-shrink-0">
              <span className="text-[10px] text-muted-foreground">Sem alérgeno:</span>
              {ALERGENOS_LIST.map((a) => {
                const active = addSemAlergenos.has(a.sigla)
                return (
                  <button
                    key={a.sigla}
                    onClick={() => {
                      setAddSemAlergenos(prev => {
                        const next = new Set(prev)
                        if (next.has(a.sigla)) next.delete(a.sigla)
                        else next.add(a.sigla)
                        return next
                      })
                    }}
                    className={`px-1.5 py-0.5 rounded text-[9px] font-bold border transition-colors ${
                      active
                        ? 'bg-red-50 border-red-300 text-red-700'
                        : 'bg-white border-gray-200 text-gray-500 hover:border-gray-300'
                    }`}
                    title={`Excluir preparações com ${a.nome}`}
                  >
                    {a.sigla} {a.nome}
                  </button>
                )
              })}
            </div>

            {/* Selected count */}
            {addSelectedPrepIds.size > 0 && (
              <div className="flex items-center gap-2 px-2 py-1.5 rounded-lg bg-[#1A3A5C]/5 border border-[#1A3A5C]/10 flex-shrink-0">
                <Check className="w-3.5 h-3.5 text-[#1A3A5C]" />
                <span className="text-xs font-medium text-[#1A3A5C]">{addSelectedPrepIds.size} selecionada(s)</span>
                {addExistingItems.size > 0 && (addNovasPreparacoes.length > 0 || addItensParaRemover.length > 0) && (
                  <span className="text-[10px] flex items-center gap-1.5">
                    {addNovasPreparacoes.length > 0 && (
                      <span className="text-emerald-600 font-bold">+{addNovasPreparacoes.length} nova(s)</span>
                    )}
                    {addItensParaRemover.length > 0 && (
                      <span className="text-red-600 font-bold">−{addItensParaRemover.length} p/ remover</span>
                    )}
                  </span>
                )}
                <button
                  onClick={() => setAddSelectedPrepIds(new Set())}
                  className="ml-auto text-[10px] text-muted-foreground hover:text-foreground underline"
                >
                  {addExistingItems.size > 0 ? 'Desmarcar todas' : 'Limpar seleção'}
                </button>
              </div>
            )}

            {/* Preparations list — v9.9.5: scroll nativo sempre visível + bloco "Selecionadas" fixo no topo */}
            <div className="flex-1 min-h-0 overflow-y-auto border rounded-lg bg-white [&::-webkit-scrollbar]:w-2.5 [&::-webkit-scrollbar-track]:bg-slate-100/70 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300">
              <div className="p-1">
                {/* v9.9.5: selecionadas (existentes + marcadas agora) sempre no topo, na ordem da lista */}
                {selecionadasNaOrdem.length > 0 && (
                  <div className="mb-1.5 rounded-md border border-[#1A3A5C]/25 bg-[#1A3A5C]/[0.04] overflow-hidden">
                    <div className="flex items-center gap-1.5 px-2 py-1 bg-[#1A3A5C]/10 border-b border-[#1A3A5C]/10">
                      <Check className="w-3 h-3 text-[#1A3A5C] flex-shrink-0" />
                      <span className="text-[9px] font-bold uppercase tracking-wide text-[#1A3A5C]">
                        Selecionadas ({selecionadasNaOrdem.length})
                      </span>
                      <span className="text-[9px] text-[#1A3A5C]/50">— sempre no topo, na ordem da lista</span>
                    </div>
                    <div className="p-0.5">
                      {selecionadasNaOrdem.map((p) => renderPrepRow(p))}
                    </div>
                  </div>
                )}

                {gruposPreparacoes.length > 0 ? (
                  gruposPreparacoes.map((grupo) => (
                    <div key={grupo.categoria}>
                      {/* Cabeçalho da categoria */}
                      <div className="sticky top-0 z-10 flex items-center gap-1.5 px-2 py-1 bg-white/95 backdrop-blur-sm border-b border-gray-100">
                        <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: grupo.cor }} />
                        <span className="text-[9px] font-bold uppercase tracking-wide text-muted-foreground">{grupo.label}</span>
                        <span className="text-[9px] text-muted-foreground/70">({grupo.itens.length})</span>
                      </div>
                      {grupo.itens.map((p) => renderPrepRow(p))}
                    </div>
                  ))
                ) : selecionadasNaOrdem.length > 0 ? (
                  <p className="text-[10px] text-muted-foreground text-center py-4">
                    Todas as preparações do filtro atual já estão selecionadas (bloco acima)
                  </p>
                ) : (
                  <p className="text-xs text-muted-foreground text-center py-8">
                    {addPrepSearch ? 'Nenhuma preparação encontrada' : 'Nenhuma preparação cadastrada'}
                  </p>
                )}
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2 flex-shrink-0">
            {/* v8: Botão para criar nova preparação — abre sub-dialog (não abre nova aba) */}
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={openNewPrepInDialog}
              className="text-blue-600 border-blue-200 hover:bg-blue-50 hover:text-blue-700 mr-auto"
            >
              <Plus className="w-3 h-3 mr-1" /> Nova Preparação
            </Button>
            <Button variant="outline" size="sm" onClick={() => setAddDialogOpen(false)} disabled={adding}>Cancelar</Button>
            <Button
              size="sm"
              onClick={handleAddPreparacoes}
              disabled={adding || (addNovasPreparacoes.length === 0 && addItensParaRemover.length === 0)}
              className="bg-[#1A3A5C] hover:bg-[#1A3A5C]/90"
            >
              {adding ? 'Salvando...' : (
                addNovasPreparacoes.length > 0 && addItensParaRemover.length > 0
                  ? `Salvar (+${addNovasPreparacoes.length} / −${addItensParaRemover.length})`
                  : addNovasPreparacoes.length > 0
                    ? `Adicionar ${addNovasPreparacoes.length} preparação(ões)`
                    : `Remover ${addItensParaRemover.length} preparação(ões)`
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══ v9.9.7: Localizar Preparação (somente consulta + navegar) ═══ */}
      <Dialog open={locDialogOpen} onOpenChange={setLocDialogOpen}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] flex flex-col gap-3 p-5 overflow-hidden">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="text-[#1A3A5C] text-sm flex items-center gap-1.5">
              <Search className="w-4 h-4 text-blue-600" />
              Localizar Preparação
            </DialogTitle>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Onde essa preparação está no cardápio? Clique na ocorrência para ir até a semana.
            </p>
          </DialogHeader>

          <div className="flex-1 min-h-0 flex flex-col gap-3 overflow-y-auto pr-0.5 [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300">
            <div className="relative flex-shrink-0">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground" />
              <Input
                placeholder="Digite o nome da preparação (mín. 2 letras)..."
                value={locBusca}
                onChange={(e) => setLocBusca(e.target.value)}
                className="pl-8 h-8 text-xs"
                autoFocus
              />
            </div>

            <div className="min-h-[120px]">
              {locBuscando && (
                <p className="text-xs text-muted-foreground text-center py-8">Buscando ocorrências...</p>
              )}
              {!locBuscando && locBusca.trim().length < 2 && (
                <p className="text-[10px] text-muted-foreground text-center py-8 leading-relaxed">
                  Ex.: "arroz", "suco" — mostra todas as ocorrências no cardápio inteiro
                  (semana, dia e refeição). Clique para navegar até elas.
                </p>
              )}
              {!locBuscando && locBusca.trim().length >= 2 && locResultados && locResultados.length === 0 && (
                <p className="text-xs text-muted-foreground text-center py-8">Nenhuma ocorrência encontrada</p>
              )}
              {!locBuscando && locResultados && locResultados.length > 0 && (
                <div className="space-y-1.5">
                  {locResultados.map((r) => {
                    // v9.9.7: nº de semanas distintas em que a preparação aparece
                    const semanasCount = new Set(r.ocorrencias.map(o => o.semana_num)).size
                    const aberto = locPrepAberta === r.preparacao_id
                    return (
                      <div key={r.preparacao_id} className="rounded-lg border border-gray-200 overflow-hidden">
                        <button
                          onClick={() => setLocPrepAberta(aberto ? null : r.preparacao_id)}
                          className="w-full flex items-center gap-2 px-2.5 py-2 hover:bg-[#1A3A5C]/5 transition-colors text-left"
                        >
                          <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: getCategoriaInfo(r.categoria || 'PREPARACAO').cor }} />
                          <span className="text-xs font-medium text-[#1A3A5C] truncate flex-1 min-w-0" title={r.preparacao_nome}>{r.preparacao_nome}</span>
                          <Badge className="bg-[#1A3A5C]/10 text-[#1A3A5C] hover:bg-[#1A3A5C]/10 text-[9px] flex-shrink-0">
                            {r.ocorrencias.length} ocorrência{r.ocorrencias.length !== 1 ? 's' : ''}
                          </Badge>
                          <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 text-[9px] flex-shrink-0">
                            {semanasCount} sem.
                          </Badge>
                          {aberto ? <ChevronUp className="w-3 h-3 text-muted-foreground flex-shrink-0" /> : <ChevronDown className="w-3 h-3 text-muted-foreground flex-shrink-0" />}
                        </button>
                        {aberto && (
                          <div className="border-t border-gray-100 p-1 space-y-0.5 bg-gray-50/50">
                            {r.ocorrencias.map((o) => (
                              <button
                                key={o.item_id}
                                onClick={() => irParaOcorrencia(o)}
                                className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-blue-50 border border-transparent hover:border-blue-200 transition-colors text-left text-xs"
                              >
                                <span className="font-bold text-[#1A3A5C] flex-shrink-0">S{String(o.semana_num).padStart(2, '0')}</span>
                                <span className="text-muted-foreground flex-shrink-0">{DIAS_SEMANA_NUTRI.find(d => d.value === o.dia_semana)?.label || o.dia_semana}</span>
                                <span className="text-muted-foreground truncate" title={o.tipo_refeicao_nome}>{o.tipo_refeicao_nome}</span>
                                <span className="ml-auto flex items-center gap-0.5 text-[10px] font-semibold text-blue-600 flex-shrink-0">
                                  Ir <ArrowRight className="w-3 h-3" />
                                </span>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          </div>

          <DialogFooter className="flex-shrink-0">
            <Button variant="outline" size="sm" onClick={() => setLocDialogOpen(false)}>Fechar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══ v9.9.9: Analisador de Repetições ═══ */}
      <Dialog open={repDialogOpen} onOpenChange={setRepDialogOpen}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] flex flex-col gap-3 p-5 overflow-hidden">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="text-[#1A3A5C] text-sm flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-indigo-600" />
              Analisar Repetições
            </DialogTitle>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Varre o cardápio inteiro (todas as semanas) e aponta preparações repetitivas:
              2× no mesmo dia, dias seguidos, concentração num único dia da semana e pouca variedade por refeição.
            </p>
          </DialogHeader>

          {!analiseRep ? (
            <div className="flex-1 flex items-center justify-center text-xs text-muted-foreground">Analisando...</div>
          ) : analiseRep.totalItens === 0 ? (
            <div className="flex-1 flex items-center justify-center text-xs text-muted-foreground py-10 text-center px-4">
              Nenhum item no cardápio ainda — adicione preparações para analisar repetições.
            </div>
          ) : (
            <div className="flex-1 min-h-0 flex flex-col gap-3 overflow-y-auto pr-0.5 [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300">
              {/* ── Resumo geral ── */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 flex-shrink-0">
                <div className="p-2 rounded-lg border border-[#1A3A5C]/10 bg-[#1A3A5C]/5">
                  <p className="text-[9px] text-muted-foreground uppercase font-bold">Itens no cardápio</p>
                  <p className="text-lg font-bold text-[#1A3A5C] leading-tight">{analiseRep.totalItens}</p>
                  <p className="text-[9px] text-muted-foreground">{analiseRep.resumo.distintas} preparações distintas</p>
                </div>
                <div className={`p-2 rounded-lg border ${analiseRep.resumo.vermelhas > 0 ? 'border-red-200 bg-red-50' : 'border-gray-100 bg-gray-50'}`}>
                  <p className="text-[9px] text-muted-foreground uppercase font-bold">Repetição forte</p>
                  <p className={`text-lg font-bold leading-tight ${analiseRep.resumo.vermelhas > 0 ? 'text-red-600' : 'text-gray-400'}`}>{analiseRep.resumo.vermelhas}</p>
                  <p className="text-[9px] text-muted-foreground">preparação(ões) em vermelho</p>
                </div>
                <div className={`p-2 rounded-lg border ${analiseRep.resumo.amarelas > 0 ? 'border-amber-200 bg-amber-50' : 'border-gray-100 bg-gray-50'}`}>
                  <p className="text-[9px] text-muted-foreground uppercase font-bold">Atenção</p>
                  <p className={`text-lg font-bold leading-tight ${analiseRep.resumo.amarelas > 0 ? 'text-amber-600' : 'text-gray-400'}`}>{analiseRep.resumo.amarelas}</p>
                  <p className="text-[9px] text-muted-foreground">preparação(ões) em amarelo</p>
                </div>
                <div className={`p-2 rounded-lg border ${analiseRep.resumo.diasMesmoDia > 0 ? 'border-red-200 bg-red-50' : 'border-gray-100 bg-gray-50'}`}>
                  <p className="text-[9px] text-muted-foreground uppercase font-bold">2× no mesmo dia</p>
                  <p className={`text-lg font-bold leading-tight ${analiseRep.resumo.diasMesmoDia > 0 ? 'text-red-600' : 'text-gray-400'}`}>{analiseRep.resumo.diasMesmoDia}</p>
                  <p className="text-[9px] text-muted-foreground">de {analiseRep.totalDiasLetivos} dias letivos</p>
                </div>
              </div>

              {/* ── Variedade por refeição ── */}
              <div className="space-y-1.5 flex-shrink-0">
                <Label className="text-[10px] font-bold text-muted-foreground uppercase">Variedade por refeição</Label>
                <div className="rounded-lg border border-gray-200 p-2 space-y-1">
                  {analiseRep.porRefeicao.map(r => (
                    <div key={r.tipo_refeicao_id} className="text-[10px] leading-relaxed flex flex-wrap items-baseline gap-x-1.5">
                      <span className="font-bold text-[#1A3A5C]">{r.nome}:</span>
                      <span className="text-muted-foreground">{r.distintas} preparações distintas · mais usadas:</span>
                      {r.top.map((t, i) => (
                        <span key={i} className="text-[#1A3A5C] font-medium">
                          {t.nome} ({t.total}×){i < r.top.length - 1 ? ',' : ''}
                        </span>
                      ))}
                    </div>
                  ))}
                </div>
              </div>

              {/* ── Filtros do ranking ── */}
              <div className="flex items-center gap-2 flex-shrink-0 flex-wrap">
                <Select value={repCat} onValueChange={(v) => { setRepCat(v); setRepCardAberto(null) }}>
                  <SelectTrigger className="h-7 text-[11px] w-[190px] flex-shrink-0">
                    <SelectValue placeholder="Categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as categorias</SelectItem>
                    {repCategoriasPresentes.map(c => (
                      <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <button
                  onClick={() => { setRepSoAlertas(v => !v); setRepCardAberto(null) }}
                  className={`inline-flex items-center gap-1.5 h-7 px-2 rounded-md border text-[11px] font-medium transition-colors flex-shrink-0 ${
                    repSoAlertas ? 'bg-indigo-50 border-indigo-300 text-indigo-700' : 'bg-white border-gray-200 text-muted-foreground hover:bg-gray-50'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${repSoAlertas ? 'bg-indigo-500' : 'bg-gray-300'}`} />
                  Só com alertas
                </button>
                <span className="text-[10px] text-muted-foreground ml-auto">{repFiltradas.length} preparação(ões)</span>
              </div>

              {/* ── Ranking de repetições ── */}
              <div className="space-y-1.5">
                {repFiltradas.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-6 leading-relaxed">
                    {repSoAlertas && analiseRep.resumo.vermelhas === 0 && analiseRep.resumo.amarelas === 0
                      ? 'Nenhuma repetição preocupante encontrada — o cardápio está variado.'
                      : repSoAlertas
                        ? 'Nenhuma preparação com alerta neste filtro. Desative "Só com alertas" para ver todas.'
                        : 'Nenhuma preparação neste filtro.'}
                  </p>
                ) : repFiltradas.map(p => {
                  const aberto = repCardAberto === p.preparacao_id
                  return (
                    <div key={p.preparacao_id} className="rounded-lg border border-gray-200 overflow-hidden">
                      <button
                        onClick={() => setRepCardAberto(aberto ? null : p.preparacao_id)}
                        className="w-full flex items-center gap-2 px-2.5 py-2 hover:bg-[#1A3A5C]/5 transition-colors text-left"
                      >
                        <span
                          className={`w-2 h-2 rounded-full flex-shrink-0 ${
                            p.nivel === 'vermelho' ? 'bg-red-500' : p.nivel === 'amarelo' ? 'bg-amber-400' : 'bg-emerald-500'
                          }`}
                          title={p.nivel === 'vermelho' ? 'Repetição forte' : p.nivel === 'amarelo' ? 'Atenção' : 'Sem alerta'}
                        />
                        <span className="text-xs font-medium text-[#1A3A5C] truncate flex-1 min-w-0" title={p.nome}>{p.nome}</span>
                        <Badge className="bg-[#1A3A5C]/10 text-[#1A3A5C] hover:bg-[#1A3A5C]/10 text-[9px] flex-shrink-0">{p.total}×</Badge>
                        <Badge className="bg-gray-100 text-gray-600 hover:bg-gray-100 text-[9px] flex-shrink-0">{p.freqPct}% dos dias</Badge>
                        {p.mesmoDia > 0 && (
                          <Badge className="bg-red-100 text-red-700 hover:bg-red-100 text-[9px] flex-shrink-0">2× no mesmo dia ({p.mesmoDia})</Badge>
                        )}
                        {p.streakMaxSemana >= 3 && (
                          <Badge className={`text-[9px] flex-shrink-0 ${p.streakMaxSemana >= 4 ? 'bg-red-100 text-red-700 hover:bg-red-100' : 'bg-amber-100 text-amber-700 hover:bg-amber-100'}`}>
                            {p.streakMaxSemana} dias seguidos
                          </Badge>
                        )}
                        {p.consecutivos > 0 && (
                          <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-[9px] flex-shrink-0">{p.consecutivos} consec.</Badge>
                        )}
                        {p.diaFixo && (
                          <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-[9px] flex-shrink-0">{p.diaFixo.pct}% às {p.diaFixo.label}</Badge>
                        )}
                        {aberto ? <ChevronUp className="w-3 h-3 text-muted-foreground flex-shrink-0" /> : <ChevronDown className="w-3 h-3 text-muted-foreground flex-shrink-0" />}
                      </button>
                      {aberto && (
                        <div className="border-t border-gray-100 p-1 space-y-0.5 bg-gray-50/50 max-h-56 overflow-y-auto [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300">
                          {p.ocorrencias.map(o => (
                            <button
                              key={o.item_id}
                              onClick={() => { setRepDialogOpen(false); irParaOcorrencia(o) }}
                              className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-blue-50 border border-transparent hover:border-blue-200 transition-colors text-left text-xs"
                            >
                              <span className="font-bold text-[#1A3A5C] flex-shrink-0">S{String(o.semana_num).padStart(2, '0')}</span>
                              <span className="text-muted-foreground flex-shrink-0">{DIAS_SEMANA_NUTRI.find(d => d.value === o.dia_semana)?.label || o.dia_semana}</span>
                              <span className="text-muted-foreground truncate" title={o.tipo_refeicao_nome}>{o.tipo_refeicao_nome}</span>
                              <span className="ml-auto flex items-center gap-0.5 text-[10px] font-semibold text-blue-600 flex-shrink-0">
                                Ir <ArrowRight className="w-3 h-3" />
                              </span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>

              {/* ── Critérios (transparência) ── */}
              <p className="text-[9px] text-muted-foreground leading-relaxed px-0.5 flex-shrink-0">
                Critérios — <span className="text-red-600 font-semibold">Repetição forte</span>: 2+ vezes no mesmo dia, 4+ dias seguidos na mesma semana ou presente em mais de 60% dos dias letivos.
                {' '}<span className="text-amber-600 font-semibold">Atenção</span>: dias consecutivos (inclusive sexta→segunda), 3 dias seguidos na semana, mais de 40% dos dias ou concentrada em um dia da semana.
                Preparações de base (arroz, feijão, sucos) naturalmente repetem mais — avalie o conjunto.
              </p>
            </div>
          )}

          <DialogFooter className="flex-shrink-0">
            <Button variant="outline" size="sm" onClick={() => setRepDialogOpen(false)}>Fechar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══ v9.10.0: Gerar Ciclo — repetir as semanas montadas até completar as 22 ═══ */}
      <Dialog open={cicloDialogOpen} onOpenChange={setCicloDialogOpen}>
        <DialogContent className="sm:max-w-xl max-h-[90vh] flex flex-col gap-3 p-5 overflow-hidden">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="text-[#1A3A5C] text-sm flex items-center gap-1.5">
              <Repeat className="w-4 h-4 text-teal-600" />
              Gerar Ciclo de Semanas
            </DialogTitle>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Repete as semanas que você já montou até completar o semestre: ex. 6 semanas montadas
              viram 22 (S7 = S1, S8 = S2, ..., S12 = S6, S13 = S1, ...).
            </p>
          </DialogHeader>

          {!analiseCiclo ? (
            <div className="flex-1 flex items-center justify-center text-xs text-muted-foreground">Analisando semanas...</div>
          ) : analiseCiclo.ciclo === 0 ? (
            <div className="flex-1 flex items-center justify-center text-xs text-muted-foreground py-10 text-center px-4">
              Nenhuma semana tem conteúdo ainda — monte pelo menos a semana 1 antes de gerar o ciclo.
            </div>
          ) : analiseCiclo.gerar.length === 0 ? (
            <div className="flex-1 flex items-center justify-center text-xs text-muted-foreground py-10 text-center px-4">
              Todas as {analiseCiclo.total} semanas já têm conteúdo — nada a gerar.
            </div>
          ) : (
            <div className="flex-1 min-h-0 flex flex-col gap-3 overflow-y-auto pr-0.5 [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300">
              {/* Resumo: ciclo detectado × semanas a gerar */}
              <div className="grid grid-cols-2 gap-2 flex-shrink-0">
                <div className="p-2 rounded-lg border border-[#1A3A5C]/10 bg-[#1A3A5C]/5">
                  <p className="text-[9px] text-muted-foreground uppercase font-bold">Ciclo detectado</p>
                  <p className="text-lg font-bold text-[#1A3A5C] leading-tight">{analiseCiclo.ciclo} semanas</p>
                  <p className="text-[9px] text-muted-foreground">S1–S{analiseCiclo.ciclo} montadas por você</p>
                </div>
                <div className="p-2 rounded-lg border border-teal-200 bg-teal-50">
                  <p className="text-[9px] text-muted-foreground uppercase font-bold">Semanas a gerar</p>
                  <p className="text-lg font-bold text-teal-700 leading-tight">{analiseCiclo.gerar.length}</p>
                  <p className="text-[9px] text-muted-foreground">S{analiseCiclo.ciclo + 1}–S{analiseCiclo.total} como réplicas</p>
                </div>
              </div>

              {/* Aviso: semanas além do ciclo que já têm conteúdo serão substituídas */}
              {analiseCiclo.foraDoCicloComConteudo.length > 0 && (
                <div className="p-2.5 rounded-lg border border-amber-300 bg-amber-50 flex items-start gap-2 flex-shrink-0">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600 mt-0.5 flex-shrink-0" />
                  <p className="text-[10px] text-amber-800 leading-relaxed">
                    <strong>Atenção:</strong> as semanas {analiseCiclo.foraDoCicloComConteudo.map(n => `S${n}`).join(', ')} já têm
                    conteúdo e serão <strong>substituídas</strong> pelas réplicas do ciclo.
                  </p>
                </div>
              )}

              {/* Prévia do mapeamento S7=S1, S8=S2... */}
              <div className="space-y-1.5 flex-shrink-0">
                <Label className="text-[10px] font-bold text-muted-foreground uppercase">Prévia da repetição</Label>
                <div className="flex flex-wrap gap-1">
                  {analiseCiclo.mapeamento.map(m => (
                    <span
                      key={m.semana}
                      className="px-1.5 py-0.5 rounded border text-[9px] font-medium bg-teal-50 border-teal-200 text-teal-800"
                      title={`Semana ${m.semana} = cópia da semana ${m.base}`}
                    >
                      S{m.semana} = S{m.base}
                    </span>
                  ))}
                </div>
              </div>

              <p className="text-[9px] text-muted-foreground leading-relaxed px-0.5 flex-shrink-0">
                As semanas do ciclo (S1–S{analiseCiclo.ciclo}) não são alteradas. As datas são recalculadas a partir da data de
                início da semana 1. Depois de gerar, cada semana continua editável individualmente (a edição marca a semana como "Modificada").
              </p>
            </div>
          )}

          <DialogFooter className="flex-shrink-0">
            <Button variant="outline" size="sm" onClick={() => setCicloDialogOpen(false)} disabled={gerandoCiclo}>Cancelar</Button>
            {analiseCiclo && analiseCiclo.ciclo > 0 && analiseCiclo.gerar.length > 0 && (
              <Button
                size="sm"
                onClick={handleGerarCiclo}
                disabled={gerandoCiclo}
                className="bg-teal-600 hover:bg-teal-700 text-white"
              >
                {gerandoCiclo ? (
                  <>
                    <RefreshCw className="w-3 h-3 mr-1 animate-spin" /> Gerando...
                  </>
                ) : (
                  <>
                    <Repeat className="w-3 h-3 mr-1" /> Gerar semanas {analiseCiclo.ciclo + 1}–{analiseCiclo.total} ({analiseCiclo.gerar.length})
                  </>
                )}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══ v9.9.6 · retitulado v9.9.7: Substituir Preparação (parcial ou em lote) ═══ */}
      <Dialog open={subDialogOpen} onOpenChange={setSubDialogOpen}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] flex flex-col gap-3 p-5 overflow-hidden">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="text-[#1A3A5C] text-sm flex items-center gap-1.5">
              <Replace className="w-4 h-4 text-amber-600" />
              Substituir Preparação
            </DialogTitle>
          </DialogHeader>

          <div className="flex-1 min-h-0 flex flex-col gap-3 overflow-y-auto pr-0.5 [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300">
            {/* ── Etapa 1: localizar a preparação atual ── */}
            <div className="space-y-1.5">
              <Label className="text-[10px] font-bold text-muted-foreground uppercase">1 · Preparação atual (localizar)</Label>
              {!subPrepSelecionada ? (
                <>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground" />
                    <Input
                      placeholder="Digite o nome da preparação (mín. 2 letras)..."
                      value={subBusca}
                      onChange={(e) => setSubBusca(e.target.value)}
                      className="pl-8 h-8 text-xs"
                      autoFocus
                    />
                  </div>
                  <div className="min-h-[100px]">
                    {subBuscando && (
                      <p className="text-xs text-muted-foreground text-center py-6">Buscando ocorrências...</p>
                    )}
                    {!subBuscando && subBusca.trim().length < 2 && (
                      <p className="text-[10px] text-muted-foreground text-center py-6 leading-relaxed">
                        Ex.: "arroz", "suco" — mostra todas as ocorrências no cardápio inteiro (todas as semanas)
                      </p>
                    )}
                    {!subBuscando && subBusca.trim().length >= 2 && subResultados && subResultados.length === 0 && (
                      <p className="text-xs text-muted-foreground text-center py-6">Nenhuma ocorrência encontrada</p>
                    )}
                    {!subBuscando && subResultados && subResultados.length > 0 && (
                      <div className="space-y-1.5">
                        {subResultados.map((r) => (
                          <button
                            key={r.preparacao_id}
                            onClick={() => {
                              setSubPrepSelecionada(r)
                              setSubItensMarcados(new Set(r.ocorrencias.map(o => o.item_id)))
                            }}
                            className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg border border-gray-200 hover:border-[#1A3A5C]/40 hover:bg-[#1A3A5C]/5 transition-colors text-left"
                          >
                            <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: getCategoriaInfo(r.categoria || 'PREPARACAO').cor }} />
                            <span className="text-xs font-medium text-[#1A3A5C] truncate flex-1 min-w-0">{r.preparacao_nome}</span>
                            <Badge className="bg-[#1A3A5C]/10 text-[#1A3A5C] hover:bg-[#1A3A5C]/10 text-[9px] flex-shrink-0">
                              {r.ocorrencias.length} ocorrência{r.ocorrencias.length !== 1 ? 's' : ''}
                            </Badge>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <div className="p-2.5 rounded-lg border border-amber-200 bg-amber-50/60 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: getCategoriaInfo(subPrepSelecionada.categoria || 'PREPARACAO').cor }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-[#1A3A5C] truncate">{subPrepSelecionada.preparacao_nome}</p>
                    <p className="text-[9px] text-muted-foreground">{subPrepSelecionada.ocorrencias.length} ocorrência(s) no cardápio</p>
                  </div>
                  <button
                    onClick={() => { setSubPrepSelecionada(null); setSubItensMarcados(new Set()) }}
                    className="text-[10px] text-muted-foreground hover:text-foreground underline flex-shrink-0"
                  >
                    trocar
                  </button>
                </div>
              )}
            </div>

            {/* ── Ocorrências: marque as que serão substituídas (lote = todas) ── */}
            {subPrepSelecionada && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label className="text-[10px] font-bold text-muted-foreground uppercase">Marque as ocorrências a substituir</Label>
                  <button
                    onClick={() => setSubItensMarcados(
                      subItensMarcados.size === subPrepSelecionada.ocorrencias.length
                        ? new Set()
                        : new Set(subPrepSelecionada.ocorrencias.map(o => o.item_id))
                    )}
                    className="text-[10px] text-[#1A3A5C] hover:underline font-medium"
                  >
                    {subItensMarcados.size === subPrepSelecionada.ocorrencias.length ? 'Desmarcar todas' : 'Marcar todas'}
                  </button>
                </div>
                <div className="max-h-44 overflow-y-auto rounded-lg border border-gray-100 p-1 space-y-0.5 [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300">
                  {subPrepSelecionada.ocorrencias.map((o) => {
                    const marcado = subItensMarcados.has(o.item_id)
                    return (
                      <label
                        key={o.item_id}
                        onClick={(e) => { e.preventDefault(); toggleSubItem(o.item_id) }}
                        className={`flex items-center gap-2 px-2 py-1.5 rounded-md cursor-pointer text-xs transition-colors ${
                          marcado ? 'bg-amber-50 border border-amber-200' : 'hover:bg-gray-50 border border-transparent'
                        }`}
                      >
                        <Checkbox checked={marcado} className="flex-shrink-0 pointer-events-none" />
                        <span className="font-medium text-[#1A3A5C] flex-shrink-0">S{String(o.semana_num).padStart(2, '0')}</span>
                        <span className="text-muted-foreground flex-shrink-0">{DIAS_SEMANA_NUTRI.find(d => d.value === o.dia_semana)?.label || o.dia_semana}</span>
                        <span className="text-muted-foreground truncate" title={o.tipo_refeicao_nome}>{o.tipo_refeicao_nome}</span>
                      </label>
                    )
                  })}
                </div>
              </div>
            )}

            {/* ── Etapa 2: escolher a substituta ── */}
            <div className="space-y-1.5">
              <Label className="text-[10px] font-bold text-muted-foreground uppercase">2 · Substituir por</Label>
              {!subNovaAberta ? (
                <button
                  onClick={() => setSubNovaAberta(true)}
                  disabled={!subPrepSelecionada}
                  className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg border border-dashed transition-colors text-left disabled:opacity-50 disabled:cursor-not-allowed ${
                    subNovaId ? 'border-emerald-300 bg-emerald-50/50 hover:border-emerald-400' : 'border-gray-300 hover:border-[#1A3A5C]/40 hover:bg-gray-50'
                  }`}
                >
                  {subNovaId ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                      <span className="text-xs font-medium text-[#1A3A5C] truncate flex-1 min-w-0">
                        {preparacoes.find(p => p.id === subNovaId)?.nome || '—'}
                      </span>
                      <span className="text-[10px] text-muted-foreground flex-shrink-0">clique para trocar</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                      <span className="text-xs text-muted-foreground">Escolher a preparação substituta...</span>
                    </>
                  )}
                </button>
              ) : (
                <div className="space-y-1.5">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground" />
                    <Input
                      placeholder="Buscar preparação substituta..."
                      value={subNovaBusca}
                      onChange={(e) => setSubNovaBusca(e.target.value)}
                      className="pl-8 h-8 text-xs"
                      autoFocus
                    />
                  </div>
                  <div className="max-h-44 overflow-y-auto rounded-lg border border-gray-100 p-1 space-y-0.5 [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300">
                    {subNovasFiltradas.length === 0 && (
                      <p className="text-xs text-muted-foreground text-center py-4">Nenhuma preparação encontrada</p>
                    )}
                    {subNovasFiltradas.map((p) => {
                      const kcal = Math.round(kcalPreparacao(p))
                      return (
                        <button
                          key={p.id}
                          onClick={() => { setSubNovaId(p.id); setSubNovaAberta(false) }}
                          className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-[#1A3A5C]/5 border border-transparent hover:border-[#1A3A5C]/20 transition-colors text-left text-xs"
                        >
                          <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: getCategoriaInfo(p.categoria || 'PREPARACAO').cor }} />
                          <span className="font-medium truncate flex-1 min-w-0" title={p.nome}>{p.nome}</span>
                          <span className="flex items-center gap-0.5 text-[9px] text-orange-500 font-medium flex-shrink-0 whitespace-nowrap">
                            <Flame className="w-2.5 h-2.5" /> {kcal} kcal
                          </span>
                          <span className="text-[9px] text-muted-foreground flex-shrink-0">{p.ingredientes.length} ing.</span>
                        </button>
                      )
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* ── Nota sobre duplicatas ── */}
            {subPrepSelecionada && subNovaId && (
              <p className="text-[9px] text-muted-foreground leading-relaxed px-0.5">
                Se a preparação substituta já estiver em alguma refeição marcada, a preparação original é
                apenas removida ali (nunca fica duplicada no mesmo dia/refeição).
              </p>
            )}
          </div>

          <DialogFooter className="gap-2 flex-shrink-0">
            <Button variant="outline" size="sm" onClick={() => setSubDialogOpen(false)} disabled={subExecutando}>Cancelar</Button>
            <Button
              size="sm"
              onClick={handleSubstituir}
              disabled={subExecutando || !subPrepSelecionada || !subNovaId || subItensMarcados.size === 0}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              {subExecutando ? 'Substituindo...' : (
                subPrepSelecionada && subItensMarcados.size === subPrepSelecionada.ocorrencias.length
                  ? `Substituir TODAS (${subItensMarcados.size})`
                  : `Substituir selecionadas (${subItensMarcados.size})`
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══ Copy Days Dialog (Multi-Day) ═══ */}
      <Dialog open={copyDialogOpen} onOpenChange={setCopyDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-[#1A3A5C] text-sm">
              <Copy className="w-4 h-4 inline mr-1.5" />
              Copiar Refeições
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            {/* ── ORIGEM ── */}
            <div className="p-3 rounded-lg bg-gray-50 border border-gray-100 space-y-2.5">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-muted-foreground uppercase">Origem</p>
                <button
                  onClick={() => toggleAllDias(copyOrigemDias, setCopyOrigemDias, copyOrigemDias.size < 5)}
                  className="text-[10px] text-[#1A3A5C] hover:underline font-medium"
                >
                  {copyOrigemDias.size >= 5 ? 'Desmarcar todos' : 'Selecionar todos'}
                </button>
              </div>
              <Select
                value={String(copyOrigemSemana)}
                onValueChange={(v) => setCopyOrigemSemana(Number(v))}
              >
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: totalSemanas }, (_, i) => i + 1).map(n => (
                    <SelectItem key={n} value={String(n)} className="text-xs">
                      Semana {n}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex gap-1.5 flex-wrap">
                {DIAS_SEMANA_NUTRI.map(d => {
                  // Count items in this day to show badge
                  const diaData = cardapio?.semanas.find(s => s.numero === copyOrigemSemana)?.dias.find(dd => dd.dia_semana === d.value)
                  const itemCount = diaData?.itens.length || 0
                  const selected = copyOrigemDias.has(d.value)
                  return (
                    <button
                      key={d.value}
                      onClick={() => toggleDiaInSet(d.value, copyOrigemDias, setCopyOrigemDias)}
                      className={`px-2.5 py-1.5 rounded-md border text-[10px] font-medium transition-colors ${
                        selected
                          ? 'bg-[#1A3A5C] text-white border-[#1A3A5C]'
                          : 'bg-white text-gray-600 border-gray-200 hover:border-[#1A3A5C]/30'
                      }`}
                    >
                      {d.label}
                      {itemCount > 0 && (
                        <span className={`ml-1 text-[8px] ${selected ? 'text-white/70' : 'text-muted-foreground'}`}>
                          ({itemCount})
                        </span>
                      )}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* ── Arrow indicator ── */}
            <div className="flex items-center justify-center">
              <div className="w-8 h-8 rounded-full bg-[#1A3A5C]/10 flex items-center justify-center">
                <Copy className="w-3.5 h-3.5 text-[#1A3A5C]" />
              </div>
            </div>

            {/* ── DESTINO ── */}
            <div className="p-3 rounded-lg bg-blue-50/50 border border-blue-100 space-y-2.5">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-muted-foreground uppercase">Destino</p>
                <div className="flex items-center gap-2">
                  {/* v9.10.17: preset "Semana inteira" (5 dias, semana seguinte se igual) */}
                  <button
                    onClick={copiarSemanaInteira}
                    className="text-[10px] text-[#1A3A5C] hover:underline font-medium"
                    title="Marca os 5 dias na origem e no destino; se a semana destino for a mesma, usa a seguinte"
                  >
                    Semana inteira
                  </button>
                  <span className="text-gray-300">|</span>
                  <button
                    onClick={matchDestinoToOrigem}
                    className="text-[10px] text-[#1A3A5C] hover:underline font-medium"
                  >
                    Mesmos dias
                  </button>
                  <span className="text-gray-300">|</span>
                  <button
                    onClick={() => toggleAllDias(copyDestinoDias, setCopyDestinoDias, copyDestinoDias.size < 5)}
                    className="text-[10px] text-[#1A3A5C] hover:underline font-medium"
                  >
                    {copyDestinoDias.size >= 5 ? 'Desmarcar todos' : 'Selecionar todos'}
                  </button>
                </div>
              </div>
              <Select
                value={String(copyDestinoSemana)}
                onValueChange={(v) => setCopyDestinoSemana(Number(v))}
              >
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: totalSemanas }, (_, i) => i + 1).map(n => (
                    <SelectItem key={n} value={String(n)} className="text-xs">
                      Semana {n}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex gap-1.5 flex-wrap">
                {DIAS_SEMANA_NUTRI.map((d, idx) => {
                  const selected = copyDestinoDias.has(d.value)
                  // Find which origin day maps to this destination day
                  const origemSorted = DIAS_SEMANA_NUTRI.filter(dd => copyOrigemDias.has(dd.value))
                  const destinoSorted = DIAS_SEMANA_NUTRI.filter(dd => copyDestinoDias.has(dd.value))
                  const destIdx = destinoSorted.findIndex(dd => dd.value === d.value)
                  const origemMatch = destIdx >= 0 && destIdx < origemSorted.length ? origemSorted[destIdx] : null
                  return (
                    <button
                      key={d.value}
                      onClick={() => toggleDiaInSet(d.value, copyDestinoDias, setCopyDestinoDias)}
                      className={`px-2.5 py-1.5 rounded-md border text-[10px] font-medium transition-colors relative ${
                        selected
                          ? 'bg-[#1A3A5C] text-white border-[#1A3A5C]'
                          : 'bg-white text-gray-600 border-gray-200 hover:border-blue-300'
                      }`}
                    >
                      {d.label}
                      {selected && origemMatch && (
                        <span className={`ml-1 text-[8px] ${selected ? 'text-white/70' : 'text-muted-foreground'}`}>
                          ← {origemMatch.label}
                        </span>
                      )}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* ── Mapping preview (v9.10.17: par-a-par OU 1→N via mapearCopiasDias) ── */}
            {mapaCopia.origens.length > 0 && (
              <div className="p-2.5 rounded-lg bg-gray-50 border border-gray-100">
                <p className="text-[10px] font-semibold text-muted-foreground uppercase mb-1.5">
                  Mapeamento{mapaCopia.modo === 'um-para-muitos' ? ' — 1 dia → vários' : ''}
                </p>
                <div className="space-y-0.5">
                  {mapaCopia.origens.map((o, i) => {
                    const isConflict = o.origem_dia === o.destino_dia && o.origem_semana === o.destino_semana
                    return (
                      <div key={i} className={`text-[10px] flex items-center gap-1.5 ${isConflict ? 'text-red-500' : 'text-gray-600'}`}>
                        <span className="font-medium">{diaLabel(o.origem_dia)}</span>
                        <span className="text-gray-300">→</span>
                        <span className={isConflict ? 'font-medium' : ''}>{diaLabel(o.destino_dia)}</span>
                        {isConflict && <AlertTriangle className="w-3 h-3" />}
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {/* v9.10.17: bloqueio real do mapeamento (ex.: 2 origem × 3 destino) */}
            {copyOrigemDias.size > 0 && copyDestinoDias.size > 0 && mapaCopia.erro && (
              <p className="text-xs text-amber-600 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                {mapaCopia.erro}
              </p>
            )}

            {/* v9.10.17: aviso amigável do modo 1→N */}
            {mapaCopia.modo === 'um-para-muitos' && mapaCopia.origens.length > 1 && (
              <p className="text-[10px] text-emerald-700 flex items-center gap-1">
                <Check className="w-3 h-3" />
                O dia {diaLabel(mapaCopia.origens[0].origem_dia)} será copiado para os {copyDestinoDias.size} dias de destino
              </p>
            )}

            <p className="text-[10px] text-muted-foreground">
              As refeições dos dias de destino serão substituídas. Padrão: 1° dia origem → 1° dia destino;
              com <b>apenas 1 dia de origem</b>, ele vai para TODOS os destinos marcados.
            </p>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setCopyDialogOpen(false)} disabled={copying}>Cancelar</Button>
            <Button
              size="sm"
              onClick={handleCopyDays}
              disabled={copying || mapaCopia.origens.length === 0}
              className="bg-[#1A3A5C] hover:bg-[#1A3A5C]/90"
            >
              {copying ? 'Copiando...' : `Copiar ${copyOrigemDias.size} → ${copyDestinoDias.size} dia(s)`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Fase Escolar Dialog */}
      <Dialog open={faseDialogOpen} onOpenChange={setFaseDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-[#1A3A5C] text-sm">Fase Escolar — Cálculo Percapita</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <p className="text-xs text-muted-foreground">
              Selecione a fase escolar para definir qual percapita será usada nos cálculos nutricionais. Cada fase aplica um percentual sobre a quantidade base (Ens. Fund. Final = 100%).
            </p>
            <div className="space-y-2">
              {FASES_ESCOLARES.map((fase) => (
                <button
                  key={fase.value}
                  onClick={() => setSelectedFase(fase.value)}
                  className={`w-full flex items-center gap-3 p-2.5 rounded-lg border transition-colors text-left ${
                    selectedFase === fase.value
                      ? 'border-current bg-gray-50'
                      : 'border-gray-100 hover:bg-gray-50'
                  }`}
                  style={selectedFase === fase.value ? { borderColor: fase.cor, color: fase.cor } : undefined}
                >
                  <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: fase.cor }} />
                  <div className="flex-1">
                    <div className="text-xs font-semibold">{fase.label}</div>
                    <div className="text-[10px] text-muted-foreground">{fase.faixa} · {fase.percentual}% da base</div>
                  </div>
                  {selectedFase === fase.value && (
                    <CheckCircle className="w-4 h-4 flex-shrink-0" />
                  )}
                </button>
              ))}
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" size="sm" onClick={() => setFaseDialogOpen(false)}>Cancelar</Button>
              <Button size="sm" onClick={handleSaveFase} disabled={saving} className="bg-[#1A3A5C] hover:bg-[#1A3A5C]/90">
                {saving ? 'Salvando...' : 'Aplicar'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* v8: Dialog Configurar Data de Início */}
      <Dialog open={dataInicioDialogOpen} onOpenChange={setDataInicioDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-[#1A3A5C] text-sm flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Configurar Data de Início
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <p className="text-xs text-muted-foreground">
              Defina a data de início da <strong>Semana 1</strong> (deve ser uma segunda-feira).
              Todas as demais semanas serão calculadas automaticamente (semana 2 = +7 dias, etc).
              As datas são usadas para mostrar feriados no PDF e no editor.
            </p>
            <div className="space-y-2">
              <Label className="text-sm">Data de início (Segunda-feira)</Label>
              <Input
                type="date"
                value={dataInicio}
                onChange={(e) => setDataInicio(e.target.value)}
                className="text-sm"
              />
              <p className="text-[10px] text-muted-foreground">
                {dataInicio && new Date(dataInicio + 'T12:00:00').getDay() !== 1 && (
                  <span className="text-amber-600 font-medium">
                    ⚠️ Esta data não é uma segunda-feira. Recomendamos ajustar para o início da semana.
                  </span>
                )}
              </p>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" size="sm" onClick={() => setDataInicioDialogOpen(false)}>Cancelar</Button>
              <Button size="sm" onClick={handleSaveDataInicio} disabled={saving || !dataInicio} className="bg-[#1A3A5C] hover:bg-[#1A3A5C]/90">
                {saving ? 'Salvando...' : 'Atualizar Datas'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* v8: Dialog Editar Nome do Cardápio */}
      <Dialog open={nomeDialogOpen} onOpenChange={setNomeDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-[#1A3A5C] text-sm flex items-center gap-2">
              <Pencil className="w-4 h-4" />
              Editar Nome do Cardápio
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-2">
              <Label className="text-sm">Nome</Label>
              <Input
                value={editandoNome}
                onChange={(e) => setEditandoNome(e.target.value)}
                placeholder="Ex: Cardápio Creche 2025/2"
                className="text-sm"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && editandoNome.trim()) {
                    handleSaveNome()
                  }
                }}
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" size="sm" onClick={() => setNomeDialogOpen(false)}>Cancelar</Button>
              <Button size="sm" onClick={handleSaveNome} disabled={saving || !editandoNome.trim()} className="bg-[#1A3A5C] hover:bg-[#1A3A5C]/90">
                {saving ? 'Salvando...' : 'Salvar Nome'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* v8: AlertDialog de Exclusão do Cardápio */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={(v) => !deleting && setDeleteDialogOpen(v)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-red-700">
              <AlertTriangle className="w-5 h-5" />
              Excluir este cardápio?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir <strong>{cardapio?.nome}</strong>?
              <br />
              <span className="text-red-600 font-medium">
                Esta ação é irreversível e removerá TODAS as semanas, dias e itens deste cardápio.
              </span>
              <br /><br />
              Se for um cardápio de escola, o cardápio base permanece intacto. Se for um base, as instâncias já criadas nas escolas também permanecem (mas perdem o vínculo de origem).
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteCardapio}
              disabled={deleting}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleting ? 'Excluindo...' : 'Sim, excluir'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ═══ Sub-dialog: Nova/Editar Preparação (sem sair da página) ═══ */}
      <PreparacaoFormDialog
        open={prepDialogOpenInCardapio}
        onOpenChange={setPrepDialogOpenInCardapio}
        editingPrepId={editingPrepInDialog}
        editingPrep={
          editingPrepInDialog
            ? (preparacoes.find((p) => p.id === editingPrepInDialog) as PreparacaoLite | undefined)
            : null
        }
        onSaved={handlePrepSaved}
        onCloned={handlePrepCloned}
        onDeleted={handlePrepDeleted}
      />

      {/* ═══ v8.7: Dialog para editar horário customizado de refeição ═══ */}
      <Dialog open={horarioDialogOpen} onOpenChange={setHorarioDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-[#1A3A5C] text-sm flex items-center gap-2">
              <ClockIcon className="w-4 h-4" />
              Editar Horário — {horarioEditando?.nome}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <p className="text-xs text-muted-foreground">
              Defina o horário desta refeição para <b>este cardápio</b>. O padrão é{' '}
              <code className="bg-gray-100 px-1 rounded text-[10px]">{horarioEditando?.horarioDefault}</code>.
            </p>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Horário</Label>
              <Input
                value={horarioInput}
                onChange={(e) => setHorarioInput(e.target.value)}
                placeholder="Ex: 09h00 / 15h00"
                autoFocus
                className="text-sm"
              />
              <p className="text-[10px] text-muted-foreground">
                Para indicar que a refeição é servida em mais de um horário, separe com{' '}
                <code className="bg-gray-100 px-1 rounded">/</code>. Exemplo:{' '}
                <code className="bg-gray-100 px-1 rounded">09h00 / 15h00</code>.
                A preparação aparece <b>uma vez só</b> no cardápio, mas com ambos os horários discriminados.
              </p>
            </div>

            {/* Sugestões rápidas */}
            <div className="flex flex-wrap gap-1">
              <span className="text-[10px] text-muted-foreground self-center mr-1">Sugestões:</span>
              {[
                '09h00 / 15h00',
                '07h30min',
                '09h00min',
                '11h00min',
                '15h00min',
              ].map(s => (
                <button
                  key={s}
                  onClick={() => setHorarioInput(s)}
                  className="text-[10px] px-1.5 py-0.5 rounded border border-gray-200 hover:bg-gray-50 hover:border-[#1A3A5C]/30"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
          <DialogFooter className="gap-2 flex justify-between sm:justify-between">
            {/* Reset (remove override) */}
            {horarioEditando && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleResetHorario}
                disabled={salvandoHorario}
                className="text-red-600 border-red-200 hover:bg-red-50"
                title="Remove o override e volta para o horário padrão"
              >
                Restaurar padrão
              </Button>
            )}
            <div className="flex gap-2 ml-auto">
              <Button variant="outline" size="sm" onClick={() => setHorarioDialogOpen(false)} disabled={salvandoHorario}>
                Cancelar
              </Button>
              <Button
                size="sm"
                onClick={handleSaveHorario}
                disabled={salvandoHorario || !horarioInput.trim()}
                className="bg-[#1A3A5C] hover:bg-[#1A3A5C]/90"
              >
                {salvandoHorario ? 'Salvando...' : 'Salvar Horário'}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══ v9.10.17: Ajuda — manual visual completo do editor de cardápio ═══ */}
      <AjudaCardapioDialog open={ajudaDialogOpen} onOpenChange={setAjudaDialogOpen} />
    </div>
  )
}
