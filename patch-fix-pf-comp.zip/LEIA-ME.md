# Fix — PF_COMP faltava ordem_rota

Erro: `Property 'ordem_rota' is missing` no push de PF_COMP (linha 306).

Havia 5 pushes de ItemProducao, mas só 4 foram atualizados com `ordem_rota`.
O 5º (PF_COMP — complemento de pão para escolas integral) foi esquecido.

## Como aplicar
```bash
unzip patch-fix-pf-comp.zip -d .
git add -A
git commit -m "fix: adiciona ordem_rota no push de PF_COMP"
git push
```
