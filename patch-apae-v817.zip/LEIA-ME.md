# Patch v8.17 — Categoria APAE + Importação do Cardápio

## O que muda

### 1. Nova categoria de escola: APAE

Adicionada a categoria **APAE** nas listas de categorias do sistema:
- `src/lib/nutricao-utils.ts` → `CATEGORIAS_ESCOLA_NUTRI`
- `src/lib/unit-options.ts` → `CATEGORIAS_ESCOLA` e `ESCOLAS_AFETADAS`

Agora você pode cadastrar uma escola com categoria "APAE" e criar cardápios
para essa categoria.

### 2. Categoria APAE tem 3 refeições

```
1. CAFE_MANHA (Café da Manhã) — 20%
2. LANCHE (Lanche) — 60%
3. FRUTA_MANHA (Fruta) — 20%
```

### 3. Scripts incluídos

**`scripts/setup-apae-v817.ts`** — Cria a configuração da categoria APAE:
- Associa CAFE_MANHA (20%), LANCHE (60%), FRUTA_MANHA (20%) à categoria APAE
- Cria meta nutricional padrão (baseada em CRECHE)

**`scripts/importar-cardapio-apae.ts`** — Importa o cardápio APAE do CSV:
- Lê o arquivo "cardapio apae 5 semanas - Página1.csv"
- Cria cardápio "Cardápio APAE" (categoria APAE, sem escola)
- Preenche 5 semanas × 5 dias × 3 refeições
- Faz match fuzzy das preparações com o banco existente

**`cardapio apae 5 semanas - Página1.csv`** — O CSV da APAE (já incluído no patch)

## Como aplicar

### 1. Descompacte o patch na raiz do projeto

```bash
unzip patch-apae-v817.zip -d .
```

### 2. Configure a categoria APAE no banco

```bash
npx tsx scripts/setup-apae-v817.ts --apply
```

Isso cria as 3 associações (CAFE_MANHA + LANCHE + FRUTA_MANHA) na categoria APAE.

### 3. Importe o cardápio APAE

```bash
# Dry-run primeiro para ver o que será importado
npx tsx scripts/importar-cardapio-apae.ts

# Aplicar
npx tsx scripts/importar-cardapio-apae.ts --apply
```

### 4. Faça commit e push

```bash
git add -A
git commit -m "feat(v8.17): categoria APAE + importação do cardápio"
git push
```

## Após aplicar — próximos passos

1. **Cadastre a escola APAE** (se ainda não existir):
   - Vá em `/escolas`
   - Crie escola com categoria "APAE"

2. **Replicar para a escola APAE**:
   - Abra o "Cardápio APAE" (cardápio base, sem escola)
   - Clique em "Replicar p/ Escolas"
   - Selecione a escola APAE

3. **Edite o cardápio** conforme necessário

## Observações

- O CSV da APAE tem 5 semanas (não 22 como outros cardápios)
- O script cria apenas 5 semanas (não expande para 22)
- Se quiser 22 semanas, expanda manualmente via editor ou use a função "Expandir para semestre" na replicação
- O match de preparações é fuzzy — preparações sem match (score < 0.5) ficam de fora
- Veja o log do dry-run para conferir quais preparações não foram encontradas
